% function aex=aexp(epsi,lnk2,lnt1,psi);
% Compute the actual marginal utility
% March 2018
function  [y,y1,RB]=mu_d0(z2,g2,s2,z1,g1,s1,K2,B2,P2,...
    C1,R1,N1,QK1,Q1, Q0,A1, y1 ,  K1,B1,P1,PsiN_ER3,PsiN_EQ,PsiD_ER3,PsiD_EQ,d,PsiN_K,PsiN_B,PsiN_P,PsiN_A,PsiD_K,PsiD_B,PsiD_P,PsiD_A)

global Rss iy RBss   lev  lss  bgy  gamma beta  psi  alpha   Pi  xi gamma_tau  nu gss rho_z sigma_z rho_g sigma_g  lambda  omega delta kai ita tss a1  a2 ;
global po_K po_B po_P po_z po_g  Knod Bnod Pnod znod gnod  zmin gmin  Kmin Bmin Pmin zmax gmax Kmax  Bmax Pmax;
global maxiter psitol dimgrid gamma_g sss    rho_s sigma_s  smin   smax po_s snod D kappa kbs;

%%
[aaa,bbb]=size(K1);
AAA=ones(aaa,1);
CCC=zeros(aaa,1);

%% 
K2uns    = scaldown(K2,Kmin,Kmax);
B2uns    = scaldown(B2,Bmin,Bmax);
P2uns    = scaldown(P2,Pmin,Pmax);
z2uns    = scaldown(z2,zmin,zmax);
g2uns    = scaldown(g2,gmin,gmax);
s2uns    = scaldown(s2,smin,smax);

xmat_uns0       = makepoly([po_K po_B po_P po_z po_g po_s],[K2uns  B2uns  P2uns  z2uns  g2uns  s2uns  ]);

ER3_d0_d0=((xmat_uns0*PsiN_ER3));
ER3_d0_d1=((xmat_uns0*PsiD_ER3));
ER3_d0=(AAA-s2./(AAA+s2)).*ER3_d0_d0+(s2./(AAA+s2)).*ER3_d0_d1;
% EQ_d0_d0=((xmat_uns0*PsiN_EQ));
% EQ_d0_d1=((xmat_uns0*PsiD_EQ));
% EQ_d0=(AAA-s2./(AAA+s2)).*EQ_d0_d0+(s2./(AAA+s2)).*EQ_d0_d1;
EQ_d0_d0=((xmat_uns0*PsiN_EQ));
EQ_d0_d1=((1-D)*(xmat_uns0*PsiD_EQ));
EQ_d0=(AAA-s2./(AAA+s2)).*EQ_d0_d0+(s2./(AAA+s2)).*EQ_d0_d1;

pmu_d0=beta*C1.*(R1 ).*N1.*ER3_d0./( lambda*(kbs*QK1.*K2+Q1.*B2   )   );
mu_d0=AAA-pmu_d0;  
y1=mu_d0;
ccc=zeros(aaa,1);
mu_d0=max(mu_d0,ccc);

y=mu_d0;
% y1=pmu_d0;

 [ C, R , A,  Q , y00, QK, N, K, B, P, d]=solve_equilibrium_s(K2,B2,P2, z2, g2, s2,PsiN_K,PsiN_B,PsiN_P,PsiN_A,PsiD_K,PsiD_B,PsiD_P,PsiD_A); 

 RB= ( Pi*AAA+(1-Pi)*(ita*AAA+Q  ) )./Q1;
 

end
% **********************************************************************

% **********************************************************************


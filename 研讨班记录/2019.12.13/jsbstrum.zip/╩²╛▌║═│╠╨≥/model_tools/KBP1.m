function F=KBP1(xx, delta,K1, a1,  y1_d0_exp,g1,C1_d0_exp,R1_d0_exp,Rss,QK1_d0_exp, Q1_d0_exp,N1_d0_exp,xi,a2, Pi ,ita,B1,tss,gamma_tau,D)
K2_d0=xx(1);
B2_d0=xx(2);
P2_d0=xx(3);

f1=K2_d0-(((1-delta)*K1+(  a1*(( y1_d0_exp*(1-g1)-C1_d0_exp     )/K1 )^(1-xi) +a2)*K1));
f2=B2_d0-((1-D )*( Pi+(1-Pi)*(ita+Q1_d0_exp  ) )*B1+(1-0)*y1_d0_exp*g1-(tss+gamma_tau*B1))/Q1_d0_exp;
f3=P2_d0-(R1_d0_exp)*(QK1_d0_exp*K2_d0+Q1_d0_exp *B2_d0-N1_d0_exp  );

 F=[f1;f2;f3];

end

% function k2=savfun(lnk1,lnt1,psi);
% Returns the current equilibrium given state and approximation
%
% March  2018

function  [ C1, R1 , A1,  Q1 , y1, QK1, N1, K2, B2, P2,d1]=solve_equilibrium_s(K1,B1,P1, z1, g1, s1,PsiN_K,PsiN_B,PsiN_P,PsiN_A,PsiD_K,PsiD_B,PsiD_P,PsiD_A)
global Rss   psi  alpha   Pi  xi gamma_tau  nu  omega delta kai ita tss a1  a2 ;
global   rho_s sigma_s    D;
global po_K po_B po_P po_z po_g po_s Knod Bnod Pnod znod gnod snod zmin gmin smin Kmin Bmin Pmin zmax gmax smax Kmax  Bmax Pmax;
global maxiter psitol dimgrid gamma_g  ;

[aaa bbb]=size(K1);
AAA=ones(aaa,bbb);

K2uns    = scaldown(K1,Kmin,Kmax);
B2uns    = scaldown(B1,Bmin,Bmax);
P2uns    = scaldown(P1,Pmin,Pmax);
z2uns    = scaldown(z1,zmin,zmax);
g2uns    = scaldown(g1,gmin,gmax);
s2uns    = scaldown(s1,smin,smax);

xmat_uns       = makepoly([po_K po_B po_P po_z po_g po_s],[K2uns  B2uns  P2uns  z2uns  g2uns  s2uns  ]);

%% no default d=0
K2_d0      = ((xmat_uns*PsiN_K));
B2_d0      = ((xmat_uns*PsiN_B));
P2_d0      = ((xmat_uns*PsiN_P));
A1_d0      = ((xmat_uns*PsiN_A));


C1_d0=1.23*ones(aaa,1);
y1_d0=3.21*ones(aaa,1);
% RD1_d0=1.002*ones(aaa,1);
for i=1:aaa
[xx,fval]=fsolve(@cccc,[C1_d0(i,1) ;y1_d0(i,1)  ],optimoptions('fsolve','TolFun',1e-15, 'MaxIter', 1e6,'Display','off'),  K1(i,1),z1(i,1),alpha,nu,kai,delta,a1,a2,g1(i,1),xi,K2_d0(i,1),Rss,B2_d0(i,1),Pi,ita,B1(i,1),gamma_g,tss,gamma_tau,psi,P1(i,1),omega,P2_d0(i,1));
C1_d0(i,1)=xx(1);
y1_d0(i,1)=xx(2);

end

% y1_d0=((((K2_d0./K1-(1-delta+a2)*AAA)/a1).^(1/(1-xi))).*K1)./(AAA-g1)+(C1_d0 + ( kappa_D/2*( (R1)/(Rss)-1)^2* R1* ((QK1_d0*K2_d0+Q1_d0*B2_d0-N1_d0  )/( 1-rd1 )))  )/(1-g1);
% i=K2_d0.*z1-(1-delta)*K1;
% y1_d0=(C1_d0+(AAA+(i/iss-AAA).^2).*i   )./(AAA-g1);
QK1_d0=(a1*(1-xi)*(( y1_d0.*(AAA-g1)-C1_d0 )./K1  ).^(-xi)).^(-1);
Q1_d0=(( Pi+(1-Pi)*ita )*B1+(1-gamma_g)*y1_d0.*g1-(tss*AAA+gamma_tau*B1))./(B2_d0-(1-Pi)*B1);
N1_d0=psi*(( (1-delta)*QK1_d0+alpha*(y1_d0./K1)   ).*K1+ ( Pi*AAA+(1-Pi)*(ita*AAA+Q1_d0  ) ).*B1-P1   )+omega*( QK1_d0.*K1+Q1_d0.*B1 );
R1_d0=P2_d0./(QK1_d0.*K2_d0+Q1_d0 .*B2_d0-N1_d0  );
%R1_d0=((AAA-rd1).*RD1_d0+rd1.*rdr)/(xi_D  );


%%  default d=1
K2_d1      = ((xmat_uns*PsiD_K));
B2_d1      = ((xmat_uns*PsiD_B));
P2_d1      = ((xmat_uns*PsiD_P));
A1_d1      = ((xmat_uns*PsiD_A));


C1_d1=1.23*ones(aaa,1);
y1_d1=3.21*ones(aaa,1);
% RD1_d0=1.002*ones(aaa,1);
for i=1:aaa
[xx,fval]=fsolve(@cccc,[C1_d1(i,1) ;y1_d1(i,1)  ],optimoptions('fsolve','TolFun',1e-15, 'MaxIter', 1e6,'Display','off'),  K1(i,1),z1(i,1),alpha,nu,kai,delta,a1,a2,g1(i,1),xi,K2_d1(i,1),Rss,B2_d1(i,1),Pi,ita,B1(i,1),gamma_g,tss,gamma_tau,psi,P1(i,1),omega,P2_d1(i,1));
C1_d1(i,1)=xx(1);
y1_d1(i,1)=xx(2);

end

% y1_d0=((((K2_d0./K1-(1-delta+a2)*AAA)/a1).^(1/(1-xi))).*K1)./(AAA-g1)+(C1_d0 + ( kappa_D/2*( (R1)/(Rss)-1)^2* R1* ((QK1_d0*K2_d0+Q1_d0*B2_d0-N1_d0  )/( 1-rd1 )))  )/(1-g1);
% i=K2_d0.*z1-(1-delta)*K1;
% y1_d0=(C1_d0+(AAA+(i/iss-AAA).^2).*i   )./(AAA-g1);
QK1_d1=(a1*(1-xi)*(( y1_d1.*(AAA-g1)-C1_d1 )./K1  ).^(-xi)).^(-1);
Q1_d1=((1-D)*( Pi+(1-Pi)*ita )*B1+(1-gamma_g)*y1_d1.*g1-(tss*AAA+gamma_tau*B1))./(B2_d1-(1-D)*(1-Pi)*B1);
N1_d1=psi*(( (1-delta)*QK1_d1+alpha*(y1_d1./K1)   ).*K1+ (1-D)* ( Pi*AAA+(1-Pi)*(ita*AAA+Q1_d1  ) ).*B1-P1   )+omega*( QK1_d1.*K1+Q1_d1.*B1 );
R1_d1=P2_d1./(QK1_d1.*K2_d1+Q1_d1 .*B2_d1-N1_d1  );
%R1_d0=((AAA-rd1).*RD1_d0+rd1.*rdr)/(xi_D  );

%% output
% ���ΥԼ������d�������
% ddd=unifrnd (0,1+s1,1, 1);
% if ddd>s1
    C1=C1_d0; R1=R1_d0; A1=A1_d0; Q1=Q1_d0; y1=y1_d0; QK1=QK1_d0; N1=N1_d0;  K2=K2_d0; B2=B2_d0;  P2=P2_d0; d1=0;
% elseif ddd<s1
%     C1=C1_d1; R1=R1_d1; A1=A1_d1; Q1=Q1_d1; y1=y1_d1; QK1=QK1_d1; N1=N1_d1;  K2=K2_d1; B2=B2_d1;  P2=P2_d1; d1=1;
% end

end



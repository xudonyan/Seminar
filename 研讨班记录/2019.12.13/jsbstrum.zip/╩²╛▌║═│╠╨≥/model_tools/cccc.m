
% function F=ccc(C1_d0, K1,z1,alpha,nu,kai,delta,a1,a2,g1,xi,K2_d0)
function F=cccc(xx, K1,z1,alpha,nu,kai,delta,a1,a2,g1,xi,K2_d0,Rss,B2,Pi,ita,BB1,gamma_g,tss,gamma_tau,psi,PP1,omega,P2)
C1_d0=xx(1);
y1_d0=xx(2);
% RD1_d0=xx(3);
% l=xx(3);
% i=K2_d0*z1-(1-delta)*K1;
%  y1_d0=(C1_d0+(1+(i/iss-1)^2)*i   )/(1-g1);


f1=y1_d0-( ((((K2_d0/K1-(1-delta+a2))/a1)^(1/(1-xi)))*K1)/(1-g1)+(C1_d0   )/(1-g1));

f2=y1_d0-((K1*z1^(1/(alpha)))^(alpha*(1+nu)/(nu+alpha)   ))*(( (1-alpha)/(kai*C1_d0)  )^( (1-alpha)/(nu+alpha) ));

% f3=R1-((1-rd1)*RD1_d0+rd1*rdr)/(xi_D  );

% f1= y1_d0-(C1_d0+(1+(i/iss-1)^2)*i   )/(1-g1);
% f2=y1_d0-(K1/(z1))^(alpha*(1+nu)/(nu+alpha)   )*( (1-alpha)/(kai*C1_d0)  )^( (1-alpha)/(nu+alpha) );
% F=[f1;f2];

% f1=K2_d0*(z1)-((1-delta)*K1+(  a1*((z1) *( y1_d0*(1-g1)-C1_d0 )/K1  )^(1-xi) +a2 )*K1);
% f2=y1_d0-(K1/z1)^(alpha)*l^ (1-alpha);
% f3=(1-alpha)*y1_d0/C1_d0-kai*l^(1+nu);
% 
 F=[f1;f2];

 
 
end


function [ C1_d0, R1_d0 , A1_d0,  Q1_d0 , y1_d0, QK1_d0, N1_d0, K2_d0, B2_d0, P2_d0 ,C1_d1, R1_d1,  A1_d1,  Q1_d1,  y1_d1, QK1_d1, N1_d1, K2_d1, B2_d1, P2_d1]=solve_equilibrium(xmat_uns,K1,B1,P1, z1, g1, s1, PsiN_K,PsiN_B,PsiN_P,PsiN_A,PsiD_K,PsiD_B,PsiD_P,PsiD_A)
global Rss iy muss   lev  lss  bgy  gamma beta  psi  alpha   Pi  xi gamma_tau  nu gss rho_z sigma_z rho_g sigma_g  lambda  omega delta kai ita tss a1  a2 ;
global   rho_s sigma_s  smin   smax po_s snod D;
global po_K po_B po_P po_z po_g po_s Knod Bnod Pnod znod gnod snod zmin gmin smin Kmin Bmin Pmin zmax gmax smax Kmax  Bmax Pmax;
global maxiter psitol dimgrid gamma_g  ;

[aaa bbb]=size(K1);
AAA=ones(aaa,bbb);
%% no default d=0
K2_d0      = ((xmat_uns*PsiN_K));
B2_d0      = ((xmat_uns*PsiN_B));
P2_d0      = ((xmat_uns*PsiN_P));
A1_d0      = ((xmat_uns*PsiN_A));


C1_d0=1.23*ones(aaa,1);
y1_d0=3.2*ones(aaa,1);
parfor i=1:aaa
[xx,fval]=fsolve(@cccc,[C1_d0(i,1) ;y1_d0(i,1)  ],optimoptions('fsolve','TolFun',1e-15, 'MaxIter', 1e6,'Display','off'),  K1(i,1),z1(i,1),alpha,nu,kai,delta,a1,a2,g1(i,1),xi,K2_d0(i,1),Rss,B2_d0(i,1),Pi,ita,B1(i,1),gamma_g,tss,gamma_tau,psi,P1(i,1),omega,P2_d0(i,1));
C1_d0(i,1)=xx(1);
y1_d0(i,1)=xx(2);
end

QK1_d0=(a1*(1-xi)*(( y1_d0.*(AAA-g1)-C1_d0 )./K1  ).^(-xi)).^(-1);
Q1_d0=(( Pi+(1-Pi)*ita )*B1+(1-gamma_g)*y1_d0.*g1-(tss*AAA+gamma_tau*B1))./(B2_d0-(1-Pi)*B1);
N1_d0=psi*(( (1-delta)*QK1_d0+alpha*(y1_d0./K1)   ).*K1+ ( Pi*AAA+(1-Pi)*(ita*AAA+Q1_d0  ) ).*B1-P1   )+omega*( QK1_d0.*K1+Q1_d0.*B1 );
R1_d0=P2_d0./(QK1_d0.*K2_d0+Q1_d0 .*B2_d0-N1_d0  );


%% default d=1
K2_d1      = ((xmat_uns*PsiD_K));
B2_d1      = ((xmat_uns*PsiD_B));
P2_d1      = ((xmat_uns*PsiD_P));
A1_d1      = ((xmat_uns*PsiD_A));

C1_d1=1.23*ones(aaa,1);
y1_d1=3.2*ones(aaa,1);
parfor i=1:aaa
[xx,fval]=fsolve(@cccc,[C1_d1(i,1) ;y1_d1(i,1)  ],optimoptions('fsolve','TolFun',1e-15, 'MaxIter', 1e6,'Display','off'),  K1(i,1),z1(i,1),alpha,nu,kai,delta,a1,a2,g1(i,1),xi,K2_d1(i,1),Rss,B2_d1(i,1),Pi,ita,B1(i,1),gamma_g,tss,gamma_tau,psi,P1(i,1),omega,P2_d1(i,1));
C1_d1(i,1)=xx(1);
y1_d1(i,1)=xx(2);

end

QK1_d1=(a1*(1-xi)*(( y1_d1.*(AAA-g1)-C1_d1 )./K1  ).^(-xi)).^(-1);
Q1_d1=((1-D)*( Pi+(1-Pi)*ita )*B1+(1-gamma_g)*y1_d1.*g1-(tss*AAA+gamma_tau*B1))./(B2_d1-(1-D)*(1-Pi)*B1);
N1_d1=psi*(( (1-delta)*QK1_d1+alpha*(y1_d1./K1)   ).*K1+ (1-D)* ( Pi*AAA+(1-Pi)*(ita*AAA+Q1_d1  ) ).*B1-P1   )+omega*( QK1_d1.*K1+Q1_d1.*B1 );
R1_d1=P2_d1./(QK1_d1.*K2_d1+Q1_d1 .*B2_d1-N1_d1  );

end



function [Yvec, PsiN_ER3,PsiN_EQ, PsiD_ER3,PsiD_EQ]= projec_exp(z2,g2,z1,g1,s1,K2_d0,B2_d0,P2_d0, K2_d1,B2_d1,P2_d1, ...
 C1_d0,C1_d1,R1_d0,R1_d1,N1_d0,N1_d1,QK1_d0,QK1_d1,Q1_d0,Q1_d1, A1_d0, A1_d1, y1_d0 ,y1_d1,  xr, K1,B1,P1, Yvec)

global Rss iy muss   lev  lss  bgy  gamma beta  psi  alpha   Pi  xi gamma_tau  nu gss rho_z sigma_z rho_g sigma_g  lambda  omega delta kai ita tss a1  a2 ;
global  sss    rho_s sigma_s  smin   smax po_s snod D kappa;
global po_K po_B po_P po_z po_g  Knod Bnod Pnod znod gnod  zmin gmin  Kmin Bmin Pmin zmax gmax  Kmax  Bmax Pmax;
global maxiter psitol dimgrid gamma_g  yss  kbs;
[aaa bbb]=size(K2_d0);
AAA=ones(aaa,bbb);

%%
EC_d0=AAA./(C1_d0);
ER1_d0=(( (1-psi)*AAA+psi* A1_d0)./(C1_d0)  ).*QK1_d0;
ER2_d0=(( (1-psi)*AAA+psi* A1_d0)./(C1_d0)  ).*y1_d0;
ER3_d0=(( (1-psi)*AAA+psi* A1_d0)./(C1_d0)  );
EQ_d0=((( (1-psi)*AAA+psi* A1_d0)./(C1_d0)  )).* ( Pi*AAA+(1-Pi)*(ita*AAA+Q1_d0  ) ) ;
% EQ_d0=((( (1-psi)*AAA+psi* A1_d0)./(C1_d0)  )).*Q1_d0 ;
EC_d1=AAA./(C1_d1);
ER1_d1=(( (1-psi)*AAA+psi* A1_d1)./(C1_d1)  ).*QK1_d1;
ER2_d1=(( (1-psi)*AAA+psi* A1_d1)./(C1_d1)  ).*y1_d1;
ER3_d1=(( (1-psi)*AAA+psi* A1_d1)./(C1_d1)  );
EQ_d1=((( (1-psi)*AAA+psi* A1_d1)./(C1_d1)  )).*( Pi*AAA+(1-Pi)*(ita*AAA+Q1_d1  ) )*(1-D) ;
% EQ_d1=((( (1-psi)*AAA+psi* A1_d1)./(C1_d1)  )).*Q1_d1 ;

PsiN_EC    = xr*EC_d0;
PsiN_ER1    = xr*ER1_d0;
PsiN_ER2    = xr*ER2_d0;
PsiN_ER3   = xr*ER3_d0;
PsiN_EQ    = xr*EQ_d0;
PsiD_EC    = xr*EC_d1;
PsiD_ER1    = xr*ER1_d1;
PsiD_ER2    = xr*ER2_d1;
PsiD_ER3   = xr*ER3_d1;
PsiD_EQ    = xr*EQ_d1;

%% d=0
s2=(exp(sss)^(1-rho_s))*exp(sigma_s^2/2)*(s1.^rho_s).*((K1./K2_d0).^kappa);

K2uns    = scaldown(K2_d0,Kmin,Kmax);
B2uns    = scaldown(B2_d0,Bmin,Bmax);
P2uns    = scaldown(P2_d0,Pmin,Pmax);
z2uns    = scaldown(z2,zmin,zmax);
g2uns    = scaldown(g2,gmin,gmax);
s2uns    = scaldown(s2,smin,smax);

xmat_uns0       = makepoly([po_K po_B po_P po_z po_g po_s],[K2uns  B2uns  P2uns  z2uns  g2uns  s2uns  ]);
% mu
ER3_d0_d0=((xmat_uns0*PsiN_ER3));
ER3_d0_d1=((xmat_uns0*PsiD_ER3));
ER3_d0=(AAA-s2./(AAA+s2)).*ER3_d0_d0+(s2./(AAA+s2)).*ER3_d0_d1;
pmu_d0=beta*C1_d0.*(R1_d0 ).*N1_d0.*ER3_d0./( lambda*(kbs*QK1_d0.*K2_d0+Q1_d0.*B2_d0   )   );
mu_d0=AAA-pmu_d0;  
ccc=zeros(aaa,1);
mu_d0=max(mu_d0,ccc);
% C
EC_d0_d0=((xmat_uns0*PsiN_EC));
EC_d0_d1=((xmat_uns0*PsiD_EC));
EC_d0=(AAA-s2./(AAA+s2)).*EC_d0_d0+(s2./(AAA+s2)).*EC_d0_d1;
C1_d0_exp=AAA./( beta*R1_d0.*EC_d0 );
% R
ER1_d0_d0=((xmat_uns0*PsiN_ER1));
ER1_d0_d1=((xmat_uns0*PsiD_ER1));
ER1_d0=(AAA-s2./(AAA+s2)).*ER1_d0_d0+(s2./(AAA+s2)).*ER1_d0_d1;
ER2_d0_d0=((xmat_uns0*PsiN_ER2));
ER2_d0_d1=((xmat_uns0*PsiD_ER2));
ER2_d0=(AAA-s2./(AAA+s2)).*ER2_d0_d0+(s2./(AAA+s2)).*ER2_d0_d1;
R1_d0_exp=(((1-delta)*beta*C1_d0_exp./QK1_d0).*ER1_d0+(alpha*beta*C1_d0_exp./(QK1_d0.*K2_d0)).*ER2_d0-lambda*kbs*mu_d0)./( (beta*C1_d0.*ER3_d0)  );
C1_d0_exp=AAA./( beta*R1_d0_exp.*EC_d0 );

% A
Yvec(:,4)=(beta*C1_d0_exp.*(R1_d0).*ER3_d0)./(AAA-mu_d0);
% Q
EQ_d0_d0= ((xmat_uns0*PsiN_EQ)) ;
EQ_d0_d1=((xmat_uns0*PsiD_EQ)) ;
EQ_d0=(AAA-s2./(AAA+s2)).*EQ_d0_d0+(s2./(AAA+s2)).*EQ_d0_d1;
Q1_d0_exp=(beta*C1_d0_exp.*EQ_d0)./(lambda*mu_d0+ (beta*C1_d0_exp.*(R1_d0_exp).*ER3_d0) );

% solve K B P
y1_d0_exp=((K1.*(  z1.^(1/(alpha))  )).^(alpha*(1+nu)/(nu+alpha)   )).*(( (1-alpha)*AAA./(kai*C1_d0_exp)  ).^( (1-alpha)/(nu+alpha) ));
QK1_d0_exp=(AAA/(a1*(1-xi)).*(( y1_d0_exp.*(AAA-g1)-C1_d0_exp )./K1  ).^(xi));   %%
N1_d0_exp=psi*(( (1-delta)*QK1_d0_exp+alpha*(y1_d0_exp./K1)   ).*K1+ ( Pi*AAA+(1-Pi)*(ita*AAA+Q1_d0_exp  ) ).*B1-P1   )+omega*( QK1_d0_exp.*K1+Q1_d0_exp.*B1 );


K2_d0_exp=31*ones(aaa,1);
B2_d0_exp=4.8*ones(aaa,1);
P2_d0_exp=24*ones(aaa,1);
parfor i=1:aaa
[xx,fval]=fsolve(@KBP,[K2_d0_exp(i,1);B2_d0_exp(i,1)  ;P2_d0_exp(i,1) ] ,optimoptions('fsolve','TolFun',1e-15, 'MaxIter', 1e6,'Display','off'),  delta,K1(i,1), a1,  y1_d0_exp(i,1),g1(i,1),C1_d0_exp(i,1), ...
    R1_d0_exp(i,1),Rss,QK1_d0_exp(i,1), Q1_d0_exp(i,1),N1_d0_exp(i,1),xi,a2, ...
   Pi ,ita,B1(i,1),tss,gamma_tau);
K2_d0_exp(i,1)=xx(1);
B2_d0_exp(i,1)=xx(2);
P2_d0_exp(i,1)=xx(3);
end
Yvec(:,1)=K2_d0_exp;
Yvec(:,2)=B2_d0_exp;
Yvec(:,3)=P2_d0_exp;


%% d=1
s2=(exp(sss)^(1-rho_s))*exp(sigma_s^2/2)*(s1.^rho_s).*((K1./K2_d1).^kappa);

K2uns    = scaldown(K2_d1,Kmin,Kmax);
B2uns    = scaldown(B2_d1,Bmin,Bmax);
P2uns    = scaldown(P2_d1,Pmin,Pmax);
z2uns    = scaldown(z2,zmin,zmax);
g2uns    = scaldown(g2,gmin,gmax);
s2uns    = scaldown(s2,smin,smax);

xmat_uns0       = makepoly([po_K po_B po_P po_z po_g po_s],[K2uns  B2uns  P2uns  z2uns  g2uns  s2uns  ]);
% mu
ER3_d1_d0=((xmat_uns0*PsiN_ER3));
ER3_d1_d1=((xmat_uns0*PsiD_ER3));
ER3_d1=(AAA-s2./(AAA+s2)).*ER3_d1_d0+(s2./(AAA+s2)).*ER3_d1_d1;
pmu_d1=beta*C1_d1.*(R1_d1 ).*N1_d1.*ER3_d1./( lambda*(kbs*QK1_d1.*K2_d1+Q1_d1.*B2_d1   )   );
mu_d1=AAA-pmu_d1;  
ccc=zeros(aaa,1);
mu_d1=max(mu_d1,ccc);
% C
EC_d1_d0=((xmat_uns0*PsiN_EC));
EC_d1_d1=((xmat_uns0*PsiD_EC));
EC_d1=(AAA-s2./(AAA+s2)).*EC_d1_d0+(s2./(AAA+s2)).*EC_d1_d1;
C1_d1_exp=AAA./( beta*R1_d1.*EC_d1 );
% R
ER1_d1_d0=((xmat_uns0*PsiN_ER1));
ER1_d1_d1=((xmat_uns0*PsiD_ER1));
ER1_d1=(AAA-s2./(AAA+s2)).*ER1_d1_d0+(s2./(AAA+s2)).*ER1_d1_d1;
ER2_d1_d0=((xmat_uns0*PsiN_ER2));
ER2_d1_d1=((xmat_uns0*PsiD_ER2));
ER2_d1=(AAA-s2./(AAA+s2)).*ER2_d1_d0+(s2./(AAA+s2)).*ER2_d1_d1;
R1_d1_exp=(((1-delta)*beta*C1_d1_exp./QK1_d1).*ER1_d1+(alpha*beta*C1_d1_exp./(QK1_d1.*K2_d1)).*ER2_d1-lambda*kbs*mu_d1)./( (beta*C1_d1.*ER3_d1)  );
C1_d1_exp=AAA./( beta*R1_d1_exp.*EC_d1 );

% A
Yvec(:,8)=(beta*C1_d1_exp.*(R1_d1).*ER3_d1)./(AAA-mu_d1);
% Q
EQ_d1_d0= ((xmat_uns0*PsiN_EQ)) ;
EQ_d1_d1=((xmat_uns0*PsiD_EQ)) ;
EQ_d1=(AAA-s2./(AAA+s2)).*EQ_d1_d0+(s2./(AAA+s2)).*EQ_d1_d1;
Q1_d1_exp=(beta*C1_d1_exp.*EQ_d1  )./(lambda*mu_d1+ (beta*C1_d1_exp.*(R1_d1_exp).*ER3_d1) );

% solve K B P
y1_d1_exp=((K1.*(  z1.^(1/(alpha))  )).^(alpha*(1+nu)/(nu+alpha)   )).*(( (1-alpha)*AAA./(kai*C1_d1_exp)  ).^( (1-alpha)/(nu+alpha) ));
QK1_d1_exp=(AAA/(a1*(1-xi)).*(( y1_d1_exp.*(AAA-g1)-C1_d1_exp )./K1  ).^(xi));   %%
N1_d1_exp=psi*(( (1-delta)*QK1_d1_exp+alpha*(y1_d1_exp./K1)   ).*K1+ (1-D )*( Pi*AAA+(1-Pi)*(ita*AAA+Q1_d1_exp  ) ).*B1-P1   )+omega*( QK1_d1_exp.*K1+Q1_d1_exp.*B1 );


K2_d1_exp=31*ones(aaa,1);
B2_d1_exp=4.83*ones(aaa,1);
P2_d1_exp=24*ones(aaa,1);
parfor i=1:aaa
[xx,fval]=fsolve(@KBP1,[K2_d1_exp(i,1);B2_d1_exp(i,1)  ;P2_d1_exp(i,1) ] ,optimoptions('fsolve','TolFun',1e-15, 'MaxIter', 1e6,'Display','off'),  delta,K1(i,1), a1,  y1_d1_exp(i,1),g1(i,1),C1_d1_exp(i,1), ...
    R1_d1_exp(i,1),Rss,QK1_d1_exp(i,1), Q1_d1_exp(i,1),N1_d1_exp(i,1),xi,a2, ...
   Pi ,ita,B1(i,1),tss,gamma_tau,D);
K2_d1_exp(i,1)=xx(1);
B2_d1_exp(i,1)=xx(2);
P2_d1_exp(i,1)=xx(3);
end
Yvec(:,5)=K2_d1_exp;
Yvec(:,6)=B2_d1_exp;
Yvec(:,7)=P2_d1_exp;


end


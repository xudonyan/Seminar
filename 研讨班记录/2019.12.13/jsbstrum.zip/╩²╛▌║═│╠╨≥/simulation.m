%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%     �ط�����ծ���������ڲ��ŷ��յġ�˫�������ṹ�������ڷ�����DSGEģ�͵ķ���
%
%     ���ģ��
%
%     December  2018
%
%     Written by Chen Xiong
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc
clear
path('model_tools',path);
path('mat',path);
path('general_tools',path);


%%
global Rss  RBss   lev  lss  bgy  gamma beta  psi  alpha   Pi  xi gamma_tau  nu gss rho_z sigma_z rho_g sigma_g  lambda  omega delta kai ita tss a1  a2 ;
global po_K po_B po_P po_z po_g  Knod Bnod Pnod znod gnod  zmin gmin  Kmin Bmin Pmin zmax gmax Kmax  Bmax Pmax;
global maxiter psitol  gamma_g sss    rho_s sigma_s  smin   smax po_s snod D kappa  kbs;

Rss=1/0.99;
delta=0.025;
RBss=1/0.99+0.00435;
kbs=0.5/0.435;
lev=3;
lss=1/3;
bgy=0.135;
beta=1/Rss; 
gamma=1;

psi=0.96;
alpha=0.5;
Pi=0.05;
xi=0.42;

gamma_tau=1;
nu=1/3;
gss=0.197;
gamma_g=0.0;

rho_z=0.74;
sigma_z=0.0054;
rho_g=0.71;
sigma_g=0.016;


rho_s=0.95;
sigma_s=0.33;
D=0.0978;
kappa=70;
sss=-5.2;

load M_params
load oo_steady_state
load oo_var

lambda=M_params(20);
omega=M_params(21);
delta =M_params(22);
kai=M_params(23); 
ita=M_params(24); 
tss=M_params(25); 
a1=M_params(26);  
a2=M_params(27);

param=M_params;

zmin   =-3; zmax   = 3;  gmin   =-3;  gmax   = 3; smin   =sss-2;  smax   = sss+2.7;  Kmin   =-4; Kmax   =4 ; Bmin   =-6; Bmax   =6; 
Pmin   =-4;  Pmax   = 4;

po_K =  2; po_B   =  2; po_P    =  2; po_z    =  2; po_g    =  2; po_s   =2;
Knod    =  3;  Bnod    = 3;Pnod    =  3;  znod    =  3;  gnod    =  3;  snod    =3;

Kss=oo_steady_state(5);
Bss=oo_steady_state(4);
Pss=oo_steady_state(6);
sdK=oo_var(5,5)^(1/2);
sdB=oo_var(4,4)^(1/2);
sdP=oo_var(6,6)^(1/2);

% Set for state space
Kmin     = Kss + Kmin*sdK;
Kmax     = Kss + Kmax*sdK;
Bmin     = Bss + Bmin*sdB;
Bmax     = Bss + Bmax*sdB;
Pmin     = Pss + Pmin*sdP;
Pmax     = Pss + Pmax*sdP;
zsig    = sigma_z/sqrt(1-rho_z^2);
gsig    = sigma_g/sqrt(1-rho_g^2);
ssig    = sigma_s/sqrt(1-rho_s^2);
zmin    = exp(zmin*zsig);
zmax    = exp(zmax*zsig);
gmin     =exp(log(gss) + gmin*gsig);
gmax     =exp(log(gss) + gmax*gsig);
smin     =exp(smin);
smax     =exp( smax);

load  PPsi.mat 
load  PsiN_ER3.mat
load  PsiN_EQ.mat
load  PsiD_ER3.mat
load  PsiD_EQ.mat

PsiN_K   = PPsi(:,1);
PsiN_B   = PPsi(:,2);
PsiN_P   = PPsi(:,3);
PsiN_A   = PPsi(:,4);
PsiD_K   = PPsi(:,5);
PsiD_B   = PPsi(:,6);
PsiD_P   = PPsi(:,7);
PsiD_A   = PPsi(:,8);


%******************************************************************************************
%                                          Stochatic steady state                         
%******************************************************************************************
simutime=1000;

K=zeros(simutime+1,1);
B=zeros(simutime+1,1);
P=zeros(simutime+1,1);
z=zeros(simutime+1,1);
g=zeros(simutime+1,1);
s=zeros(simutime+1,1);
C=zeros(simutime,1);
R=zeros(simutime,1);
A=zeros(simutime,1);
Q=zeros(simutime+1,1);
y=zeros(simutime,1);
QK=zeros(simutime,1);
N=zeros(simutime,1);
d=zeros(simutime,1);
e_z=sigma_z*randn(simutime+1,1)*0;
e_g=sigma_g*randn(simutime+1,1)*0;
e_s=sigma_s*randn(simutime+1,1)*0;

mu=zeros(simutime+1,1);
K(1)=Kss;
B(1)=Bss;
P(1)=Pss;
z(1)=1.00;
g(1)=gss;
s(1)=exp(sss);

RB=zeros(simutime,1);
% 4.1 Run the simulation
% -----------------------------------------
for ti  = 1:simutime
 
 [ C(ti), R(ti) , A(ti),  Q(ti+1) , y(ti), QK(ti), N(ti), K(ti+1), B(ti+1), P(ti+1),d(ti)]=solve_equilibrium_s(K(ti),B(ti),P(ti), z(ti), g(ti), s(ti),PsiN_K,PsiN_B,PsiN_P,PsiN_A,PsiD_K,PsiD_B,PsiD_P,PsiD_A);
 
 z2(ti)=exp(sigma_z^2/2)*(z(ti).^rho_z);
 g2(ti)=(gss^(1-rho_g))*exp(sigma_g^2/2)*(g(ti).^rho_g);
 s2(ti)=(exp(sss)^(1-rho_s))*exp(sigma_s^2/2)*(s(ti).^rho_s)./((K(ti+1)./K(ti)).^kappa);
 
 [mu(ti) ,mu_shadow(ti),RB(ti)]= feval(@mu_d0,z2(ti),g2(ti),s2(ti),z(ti),g(ti),s(ti),K(ti+1),B(ti+1),P(ti+1),...
    C(ti),R(ti),N(ti),QK(ti),Q(ti+1), Q(ti),A(ti), y(ti) , K(ti),B(ti),P(ti),PsiN_ER3,PsiN_EQ,PsiD_ER3,PsiD_EQ,d(ti),PsiN_K,PsiN_B,PsiN_P,PsiN_A,PsiD_K,PsiD_B,PsiD_P,PsiD_A);   

z(ti+1)=exp(rho_z*log(z(ti))+e_z(ti));
g(ti+1)=exp((1-rho_g)*log(gss)+rho_g*log(g(ti))+e_g(ti));
s(ti+1)=exp((1-rho_s)*sss+rho_s*log(s(ti))-kappa*log((K(ti+1)./K(ti)))+e_s(ti));
end;

K_sss=K(1000,1);
B_sss=B(1000,1);
P_sss=P(1000,1);
C_sss=C(1000,1);
R_sss=R(1000,1);
A_sss=A(1000,1);
Q_sss=Q(1000,1);
y_sss=y(1000,1);
QK_sss=QK(1000,1);
N_sss=N(1000,1);
RB_sss=RB(1000,1);
RBs_sss=RB_sss-R_sss;
mu_sss=mu(999,1);

%******************************************************************************************
%                                                   IRF                 
%******************************************************************************************
simutime=51;
load  PPsi.mat 
load  PsiN_ER3.mat
load  PsiN_EQ.mat
load  PsiD_ER3.mat
load  PsiD_EQ.mat

PsiN_K   = PPsi(:,1);
PsiN_B   = PPsi(:,2);
PsiN_P   = PPsi(:,3);
PsiN_A   = PPsi(:,4);
PsiD_K   = PPsi(:,5);
PsiD_B   = PPsi(:,6);
PsiD_P   = PPsi(:,7);
PsiD_A   = PPsi(:,8);

K=zeros(simutime+1,1);
B=zeros(simutime+1,1);
P=zeros(simutime+1,1);
z=zeros(simutime+1,1);
g=zeros(simutime+1,1);
s=zeros(simutime+1,1);
C=zeros(simutime,1);
R=zeros(simutime,1);
A=zeros(simutime,1);
Q=zeros(simutime+1,1);
y=zeros(simutime,1);
QK=zeros(simutime,1);
N=zeros(simutime,1);

e_z=zeros(simutime+1,1);
e_z(1)=0.00;
e_g=zeros(simutime+1,1);
e_g(1)=0.00;
e_s=zeros(simutime+1,1);
e_s(1)=0.00;

d=zeros(simutime,1);
mu=zeros(simutime+1,1);
K(1)=K_sss;
B(1)=B_sss;
P(1)=P_sss+1*1;
z(1)=1.0;
g(1)=gss;
s(1)=exp(sss+0);

RB=zeros(simutime,1);
% 4.1 Run the simulation
% -----------------------------------------
for ti  = 1:simutime
 
 [ C(ti), R(ti) , A(ti),  Q(ti+1) , y(ti), QK(ti), N(ti), K(ti+1), B(ti+1), P(ti+1),d(ti)]=solve_equilibrium_s(K(ti),B(ti),P(ti), z(ti), g(ti), s(ti),PsiN_K,PsiN_B,PsiN_P,PsiN_A,PsiD_K,PsiD_B,PsiD_P,PsiD_A);
 
 z2(ti)=exp(sigma_z^2/2)*(z(ti).^rho_z);
 g2(ti)=(gss^(1-rho_g))*exp(sigma_g^2/2)*(g(ti).^rho_g);
 s2(ti)=(exp(sss)^(1-rho_s))*exp(sigma_s^2/2)*(s(ti).^rho_s)./((K(ti+1)./K(ti)).^kappa);
 
 [mu(ti) ,mu_shadow(ti),RB(ti)]= feval(@mu_d0,z2(ti),g2(ti),s2(ti),z(ti),g(ti),s(ti),K(ti+1),B(ti+1),P(ti+1),...
    C(ti),R(ti),N(ti),QK(ti),Q(ti+1), Q(ti),A(ti), y(ti) , K(ti),B(ti),P(ti),PsiN_ER3,PsiN_EQ,PsiD_ER3,PsiD_EQ,d(ti),PsiN_K,PsiN_B,PsiN_P,PsiN_A,PsiD_K,PsiD_B,PsiD_P,PsiD_A);   

z(ti+1)=exp(rho_z*log(z(ti))+e_z(ti));
g(ti+1)=exp((1-rho_g)*log(gss)+rho_g*log(g(ti))+e_g(ti));
s(ti+1)=exp((1-rho_s)*sss+rho_s*log(s(ti))-kappa*log(K(ti+1)./K(ti))+e_s(ti));
end;

RB_sss=( Pi+(1-Pi)*(ita+Q_sss  ) )/Q_sss;
% ת��
s_i=(s(2:simutime)./(ones(simutime-1,1)+s(2:simutime))-exp(sss)*ones(simutime-1,1)./( ones(simutime-1,1)+ exp(sss)*ones(simutime-1,1)));
N_i=(N(2:simutime)-N_sss*ones(simutime-1,1))./( N_sss*ones(simutime-1,1) )*100;
Q_i=(Q(3:simutime+1,1)-Q_sss*ones(simutime-1,1))./( Q_sss*ones(simutime-1,1) )*100;
SR_i=(RB(2:simutime)-R(2:simutime)-RBs_sss)*400;
mu_i=mu(2:simutime)-mu_sss;
% ʵ��
I=(ones(simutime,1)-g(1:simutime,1)).*y(1:simutime,1)-C(1:simutime,1);
I_sss=(1-gss)*y_sss-C_sss;
I_i=(I(2:simutime)-I_sss*ones(simutime-1,1))./( I_sss*ones(simutime-1,1) )*100;
y_i=(y(2:simutime)-y_sss*ones(simutime-1,1))./( y_sss*ones(simutime-1,1) )*100;
B_i=(B(3:simutime+1)-B_sss*ones(simutime-1,1))./( B_sss*ones(simutime-1,1) )*100;

irf_n_bad=[N_i mu_i s_i  Q_i SR_i B_i   I_i  y_i ];
save   result_mat\irf_n_bad irf_n_bad

x=1:50;
subplot(2,4,1)
plot(x, irf_n_bad(:,1),'-','Color',[0.0 0.0 0.0],'LineWidth',1.5);hold on;title('���ڲ��ž��ʲ�'  );set(gca,'FontSize',12,'xtick',[0  10  20  30  40  50]);  set(gca,'GridLineStyle',':','GridColor','k', 'GridAlpha',0.3,'LineWidth',0.3);hold on;
subplot(2,4,2)
plot(x, irf_n_bad(:,2),'-','Color',[0.0 0.0 0.0],'LineWidth',1.5);hold on;title(  '������Լ������(%)'  );set(gca,'FontSize',12,'xtick',[0  10  20  30  40  50]);  set(gca,'GridLineStyle',':','GridColor','k', 'GridAlpha',0.3,'LineWidth',0.3);hold on;
subplot(2,4,3)
plot(x, irf_n_bad(:,3),'-','Color',[0.0 0.0 0.0],'LineWidth',1.5);hold on;title( 'ΥԼ����'   );set(gca,'FontSize',12,'xtick',[0  10  20  30  40  50]);  set(gca,'GridLineStyle',':','GridColor','k', 'GridAlpha',0.3,'LineWidth',0.3);hold on;
subplot(2,4,4)
plot(x, irf_n_bad(:,4),'-','Color',[0.0 0.0 0.0],'LineWidth',1.5);hold on;title( '�ط�����ծȯ�۸�'  );set(gca,'FontSize',12,'xtick',[0  10  20  30  40  50]);  set(gca,'GridLineStyle',':','GridColor','k', 'GridAlpha',0.3,'LineWidth',0.3);hold on;
subplot(2,4,5)
plot(x, irf_n_bad(:,5),'-','Color',[0.0 0.0 0.0],'LineWidth',1.5);hold on;title(  '�ط�����ծȯ�۲�' );set(gca,'FontSize',12,'xtick',[0  10  20  30  40  50]);  set(gca,'GridLineStyle',':','GridColor','k', 'GridAlpha',0.3,'LineWidth',0.3);hold on;
subplot(2,4,6)
plot(x, irf_n_bad(:,6),'-','Color',[0.0 0.0 0.0],'LineWidth',1.5);hold on;title( '�ط�����ծȯ��ģ' );set(gca,'FontSize',12,'xtick',[0  10  20  30  40  50]);  set(gca,'GridLineStyle',':','GridColor','k', 'GridAlpha',0.3,'LineWidth',0.3);hold on;
subplot(2,4,7)
plot(x, irf_n_bad(:,7),'-','Color',[0.0 0.0 0.0],'LineWidth',1.5);hold on;title( 'Ͷ��'  );set(gca,'FontSize',12,'xtick',[0  10  20  30  40  50]);  set(gca,'GridLineStyle',':','GridColor','k', 'GridAlpha',0.3,'LineWidth',0.3);hold on;
subplot(2,4,8)
plot(x, irf_n_bad(:,8),'-','Color',[0.0 0.0 0.0],'LineWidth',1.5);hold on;title( '����'  );set(gca,'FontSize',12,'xtick',[0  10  20  30  40  50]);  set(gca,'GridLineStyle',':','GridColor','k', 'GridAlpha',0.3,'LineWidth',0.3);hold on;
set(gcf,'position',[100,100, 1000, 280]); 



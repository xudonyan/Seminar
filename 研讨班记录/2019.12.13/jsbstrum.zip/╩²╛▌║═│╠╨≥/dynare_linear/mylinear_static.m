function [residual, g1, g2] = mylinear_static(y, x, params)
%
% Status : Computes static model for Dynare
%
% Inputs : 
%   y         [M_.endo_nbr by 1] double    vector of endogenous variables in declaration order
%   x         [M_.exo_nbr by 1] double     vector of exogenous variables in declaration order
%   params    [M_.param_nbr by 1] double   vector of parameter values in declaration order
%
% Outputs:
%   residual  [M_.endo_nbr by 1] double    vector of residuals of the static model equations 
%                                          in order of declaration of the equations
%   g1        [M_.endo_nbr by M_.endo_nbr] double    Jacobian matrix of the static model equations;
%                                                     columns: variables in declaration order
%                                                     rows: equations in order of declaration
%   g2        [M_.endo_nbr by (M_.endo_nbr)^2] double   Hessian matrix of the static model equations;
%                                                       columns: variables in declaration order
%                                                       rows: equations in order of declaration
%
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

residual = zeros( 15, 1);

%
% Model equations
%

Omega__ = params(8)*y(2)/y(2)*(1-params(9)+params(9)*y(9));
QK__ = (params(26)*(1-params(12))*((y(1)*(1-y(12))-y(2))/y(5))^(-params(12)))^(-1);
QK1__ = (params(26)*(1-params(12))*((y(1)*(1-y(12))-y(2))/y(5))^(-params(12)))^(-1);
T44 = (1-params(22))*QK1__+y(1)*params(10)/y(5);
T63 = (params(11)+(1-params(11))*(params(24)+y(8)))/y(8)-y(7);
T88 = params(26)*(y(15)/y(5))^(1-params(12))+params(27);
T123 = y(11)^(1/params(10));
T130 = (y(5)*T123)^(params(10)*(1+params(14))/(params(10)+params(14)));
T136 = ((1-params(10))/(y(2)*params(23)))^((1-params(10))/(params(10)+params(14)));
T166 = getPowerDeriv((y(1)*(1-y(12))-y(2))/y(5),(-params(12)),1);
T169 = getPowerDeriv(params(26)*(1-params(12))*((y(1)*(1-y(12))-y(2))/y(5))^(-params(12)),(-1),1);
T170 = params(26)*(1-params(12))*(1-y(12))/y(5)*T166*T169;
T185 = params(20)*(y(5)*QK__*params(29)+y(8)*y(4))*params(20)*(y(5)*QK__*params(29)+y(8)*y(4));
T204 = T169*params(26)*(1-params(12))*T166*(-1)/y(5);
T256 = T169*params(26)*(1-params(12))*T166*(-(y(1)*(1-y(12))-y(2)))/(y(5)*y(5));
T276 = getPowerDeriv(y(15)/y(5),1-params(12),1);
T293 = getPowerDeriv(y(5)*T123,params(10)*(1+params(14))/(params(10)+params(14)),1);
T354 = T169*params(26)*(1-params(12))*T166*(-y(1))/y(5);
lhs =params(8)*y(2)/y(2)*y(7);
rhs =1;
residual(1)= lhs-rhs;
lhs =Omega__*(T44/QK__-y(7));
rhs =params(20)*params(29)*y(10);
residual(2)= lhs-rhs;
lhs =Omega__*T63;
rhs =params(20)*y(10);
residual(3)= lhs-rhs;
lhs =y(9);
rhs =y(7)*Omega__/(1-y(10));
residual(4)= lhs-rhs;
lhs =y(10);
rhs =1-y(7)*Omega__*y(3)/(params(20)*(y(5)*QK__*params(29)+y(8)*y(4)));
residual(5)= lhs-rhs;
lhs =y(5);
rhs =y(5)*(1-params(22))+y(5)*T88;
residual(6)= lhs-rhs;
lhs =y(4);
rhs =((params(11)+(1-params(11))*(params(24)+y(8)))*y(4)+y(12)*y(1)*(1-params(28))-(params(25)+y(4)*params(13)))/y(8);
residual(7)= lhs-rhs;
lhs =y(6);
rhs =y(7)*(y(8)*y(4)+y(5)*QK__-y(3));
residual(8)= lhs-rhs;
lhs =y(3);
rhs =params(9)*((params(11)+(1-params(11))*(params(24)+y(8)))*y(4)+y(5)*(y(1)*params(10)/y(5)+(1-params(22))*QK__)-y(6))+(y(8)*y(4)+y(5)*QK__)*params(21);
residual(9)= lhs-rhs;
lhs =y(1);
rhs =T130*T136;
residual(10)= lhs-rhs;
lhs =y(15);
rhs =y(1)*(1-y(12))-y(2);
residual(11)= lhs-rhs;
lhs =y(13);
rhs =(params(11)+(1-params(11))*(params(24)+y(8)))/y(8);
residual(12)= lhs-rhs;
lhs =y(14);
rhs =T63;
residual(13)= lhs-rhs;
lhs =log(y(11));
rhs =log(y(11))*params(16)+params(17)*x(1);
residual(14)= lhs-rhs;
lhs =log(y(12));
rhs =(1-params(18))*log(params(15))+log(y(12))*params(18)+params(19)*x(2);
residual(15)= lhs-rhs;
if ~isreal(residual)
  residual = real(residual)+imag(residual).^2;
end
if nargout >= 2,
  g1 = zeros(15, 15);

  %
  % Jacobian matrix
  %

  g1(1,7)=params(8)*y(2)/y(2);
  g1(2,1)=Omega__*(QK__*((1-params(22))*T170+params(10)/y(5))-T44*T170)/(QK__*QK__);
  g1(2,2)=Omega__*(QK__*(1-params(22))*T204-T44*T204)/(QK__*QK__);
  g1(2,5)=Omega__*(QK__*((1-params(22))*T256+(-(y(1)*params(10)))/(y(5)*y(5)))-T44*T256)/(QK__*QK__);
  g1(2,7)=(-Omega__);
  g1(2,9)=(T44/QK__-y(7))*params(8)*y(2)/y(2)*params(9);
  g1(2,10)=(-(params(20)*params(29)));
  g1(2,12)=Omega__*(QK__*(1-params(22))*T354-T44*T354)/(QK__*QK__);
  g1(3,7)=(-Omega__);
  g1(3,8)=Omega__*((1-params(11))*y(8)-(params(11)+(1-params(11))*(params(24)+y(8))))/(y(8)*y(8));
  g1(3,9)=T63*params(8)*y(2)/y(2)*params(9);
  g1(3,10)=(-params(20));
  g1(4,7)=(-(Omega__/(1-y(10))));
  g1(4,9)=1-y(7)*params(8)*y(2)/y(2)*params(9)/(1-y(10));
  g1(4,10)=(-(y(7)*Omega__/((1-y(10))*(1-y(10)))));
  g1(5,1)=(-(y(7)*Omega__*y(3)*params(20)*y(5)*params(29)*T170))/T185;
  g1(5,2)=(-(y(7)*Omega__*y(3)*params(20)*y(5)*params(29)*T204))/T185;
  g1(5,3)=y(7)*Omega__/(params(20)*(y(5)*QK__*params(29)+y(8)*y(4)));
  g1(5,4)=(-(y(7)*Omega__*y(3)*params(20)*y(8)))/T185;
  g1(5,5)=(-(y(7)*Omega__*y(3)*params(20)*(QK__*params(29)+y(5)*params(29)*T256)))/T185;
  g1(5,7)=Omega__*y(3)/(params(20)*(y(5)*QK__*params(29)+y(8)*y(4)));
  g1(5,8)=(-(y(7)*Omega__*y(3)*params(20)*y(4)))/T185;
  g1(5,9)=y(3)*y(7)*params(8)*y(2)/y(2)*params(9)/(params(20)*(y(5)*QK__*params(29)+y(8)*y(4)));
  g1(5,10)=1;
  g1(5,12)=(-(y(7)*Omega__*y(3)*params(20)*y(5)*params(29)*T354))/T185;
  g1(6,5)=1-(1-params(22)+T88+y(5)*params(26)*(-y(15))/(y(5)*y(5))*T276);
  g1(6,15)=(-(y(5)*params(26)*T276*1/y(5)));
  g1(7,1)=(-(y(12)*(1-params(28))/y(8)));
  g1(7,4)=1-(params(11)+(1-params(11))*(params(24)+y(8))-params(13))/y(8);
  g1(7,8)=(-((y(8)*(1-params(11))*y(4)-((params(11)+(1-params(11))*(params(24)+y(8)))*y(4)+y(12)*y(1)*(1-params(28))-(params(25)+y(4)*params(13))))/(y(8)*y(8))));
  g1(7,12)=(-(y(1)*(1-params(28))/y(8)));
  g1(8,1)=(-(y(7)*y(5)*T170));
  g1(8,2)=(-(y(7)*y(5)*T204));
  g1(8,3)=y(7);
  g1(8,4)=(-(y(7)*y(8)));
  g1(8,5)=(-(y(7)*(QK__+y(5)*T256)));
  g1(8,6)=1;
  g1(8,7)=(-(y(8)*y(4)+y(5)*QK__-y(3)));
  g1(8,8)=(-(y(7)*y(4)));
  g1(8,12)=(-(y(7)*y(5)*T354));
  g1(9,1)=(-(params(9)*y(5)*((1-params(22))*T170+params(10)/y(5))+params(21)*y(5)*T170));
  g1(9,2)=(-(params(9)*y(5)*(1-params(22))*T204+params(21)*y(5)*T204));
  g1(9,3)=1;
  g1(9,4)=(-(params(9)*(params(11)+(1-params(11))*(params(24)+y(8)))+y(8)*params(21)));
  g1(9,5)=(-(params(9)*(y(1)*params(10)/y(5)+(1-params(22))*QK__+y(5)*((1-params(22))*T256+(-(y(1)*params(10)))/(y(5)*y(5))))+params(21)*(QK__+y(5)*T256)));
  g1(9,6)=params(9);
  g1(9,8)=(-(params(9)*(1-params(11))*y(4)+y(4)*params(21)));
  g1(9,12)=(-(params(9)*y(5)*(1-params(22))*T354+params(21)*y(5)*T354));
  g1(10,1)=1;
  g1(10,2)=(-(T130*(-((1-params(10))*params(23)))/(y(2)*params(23)*y(2)*params(23))*getPowerDeriv((1-params(10))/(y(2)*params(23)),(1-params(10))/(params(10)+params(14)),1)));
  g1(10,5)=(-(T136*T123*T293));
  g1(10,11)=(-(T136*T293*y(5)*getPowerDeriv(y(11),1/params(10),1)));
  g1(11,1)=(-(1-y(12)));
  g1(11,2)=1;
  g1(11,12)=y(1);
  g1(11,15)=1;
  g1(12,8)=(-(((1-params(11))*y(8)-(params(11)+(1-params(11))*(params(24)+y(8))))/(y(8)*y(8))));
  g1(12,13)=1;
  g1(13,7)=1;
  g1(13,8)=(-(((1-params(11))*y(8)-(params(11)+(1-params(11))*(params(24)+y(8))))/(y(8)*y(8))));
  g1(13,14)=1;
  g1(14,11)=1/y(11)-params(16)*1/y(11);
  g1(15,12)=1/y(12)-params(18)*1/y(12);
  if ~isreal(g1)
    g1 = real(g1)+2*imag(g1);
  end
end
if nargout >= 3,
  %
  % Hessian matrix
  %

  g2 = sparse([],[],[],15,225);
end
end

function y=dss(xx, alpha,lss,gss,nu,lev,psi,bgy,Rss,delta,R,kbs,RBss)

K=xx(1);
lambda=xx(2);

% lambda=(1-psi+psi*alphaS)/(lev*(1-muss)*Rss/( R ));
N=(bgy/(1-bgy)*K+K)/lev;
alphaS=lambda*(kbs*K+lev*N*bgy  )/N;
Omega=(1-psi+psi*alphaS)/R;
mu=1-Omega*R/alphaS;

y=lss^(1-alpha)*K^alpha;
kai=(1-alpha)/lss^(1+nu)/(1-gss-delta*K/y);
B=bgy/(1-bgy)*K;

% equations
f1=(1-psi+psi*alphaS)/Rss*(1-delta+alpha*y/K -R )-lambda*kbs*mu;
f2=Omega*(RBss-R)-lambda*mu;
y=[f1;f2];




function [residual, g1, g2, g3] = mylinear_dynamic(y, x, params, steady_state, it_)
%
% Status : Computes dynamic model for Dynare
%
% Inputs :
%   y         [#dynamic variables by 1] double    vector of endogenous variables in the order stored
%                                                 in M_.lead_lag_incidence; see the Manual
%   x         [M_.exo_nbr by nperiods] double     matrix of exogenous variables (in declaration order)
%                                                 for all simulation periods
%   params    [M_.param_nbr by 1] double          vector of parameter values in declaration order
%   it_       scalar double                       time period for exogenous variables for which to evaluate the model
%
% Outputs:
%   residual  [M_.endo_nbr by 1] double    vector of residuals of the dynamic model equations in order of 
%                                          declaration of the equations
%   g1        [M_.endo_nbr by #dynamic variables] double    Jacobian matrix of the dynamic model equations;
%                                                           rows: equations in order of declaration
%                                                           columns: variables in order stored in M_.lead_lag_incidence
%   g2        [M_.endo_nbr by (#dynamic variables)^2] double   Hessian matrix of the dynamic model equations;
%                                                              rows: equations in order of declaration
%                                                              columns: variables in order stored in M_.lead_lag_incidence
%   g3        [M_.endo_nbr by (#dynamic variables)^3] double   Third order derivative matrix of the dynamic model equations;
%                                                              rows: equations in order of declaration
%                                                              columns: variables in order stored in M_.lead_lag_incidence
%
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

%
% Model equations
%

residual = zeros(15, 1);
Omega__ = params(8)*y(7)/y(22)*(1-params(9)+params(9)*y(24));
QK__ = (params(26)*(1-params(12))*((y(6)*(1-y(17))-y(7))/y(2))^(-params(12)))^(-1);
QK1__ = (params(26)*(1-params(12))*((y(21)*(1-y(25))-y(22))/y(10))^(-params(12)))^(-1);
T55 = (1-params(22))*QK1__+y(21)*params(10)/y(10);
T58 = T55/QK__-y(12);
T75 = (params(11)+(1-params(11))*(params(24)+y(23)))/y(13)-y(12);
T101 = params(26)*(y(20)/y(2))^(1-params(12))+params(27);
T146 = y(16)^(1/params(10));
T153 = (y(2)*T146)^(params(10)*(1+params(14))/(params(10)+params(14)));
T159 = ((1-params(10))/(y(7)*params(23)))^((1-params(10))/(params(10)+params(14)));
T193 = getPowerDeriv((y(6)*(1-y(17))-y(7))/y(2),(-params(12)),1);
T196 = getPowerDeriv(params(26)*(1-params(12))*((y(6)*(1-y(17))-y(7))/y(2))^(-params(12)),(-1),1);
T197 = params(26)*(1-params(12))*(1-y(17))/y(2)*T193*T196;
T208 = params(20)*(y(10)*QK__*params(29)+y(13)*y(9))*params(20)*(y(10)*QK__*params(29)+y(13)*y(9));
T228 = getPowerDeriv((y(21)*(1-y(25))-y(22))/y(10),(-params(12)),1);
T231 = getPowerDeriv(params(26)*(1-params(12))*((y(21)*(1-y(25))-y(22))/y(10))^(-params(12)),(-1),1);
T240 = (1-params(9)+params(9)*y(24))*params(8)/y(22);
T244 = T196*params(26)*(1-params(12))*T193*(-1)/y(2);
T286 = (1-params(9)+params(9)*y(24))*(-(params(8)*y(7)))/(y(22)*y(22));
T325 = T196*params(26)*(1-params(12))*T193*(-(y(6)*(1-y(17))-y(7)))/(y(2)*y(2));
T339 = getPowerDeriv(y(20)/y(2),1-params(12),1);
T361 = getPowerDeriv(y(2)*T146,params(10)*(1+params(14))/(params(10)+params(14)),1);
T447 = T196*params(26)*(1-params(12))*T193*(-y(6))/y(2);
lhs =params(8)*y(7)/y(22)*y(12);
rhs =1;
residual(1)= lhs-rhs;
lhs =Omega__*T58;
rhs =params(20)*params(29)*y(15);
residual(2)= lhs-rhs;
lhs =Omega__*T75;
rhs =params(20)*y(15);
residual(3)= lhs-rhs;
lhs =y(14);
rhs =y(12)*Omega__/(1-y(15));
residual(4)= lhs-rhs;
lhs =y(15);
rhs =1-y(12)*Omega__*y(8)/(params(20)*(y(10)*QK__*params(29)+y(13)*y(9)));
residual(5)= lhs-rhs;
lhs =y(10);
rhs =y(2)*(1-params(22))+y(2)*T101;
residual(6)= lhs-rhs;
lhs =y(9);
rhs =((params(11)+(1-params(11))*(params(24)+y(13)))*y(1)+y(17)*y(6)*(1-params(28))-(params(25)+y(1)*params(13)))/y(13);
residual(7)= lhs-rhs;
lhs =y(11);
rhs =y(12)*(y(13)*y(9)+y(10)*QK__-y(8));
residual(8)= lhs-rhs;
lhs =y(8);
rhs =params(9)*((params(11)+(1-params(11))*(params(24)+y(13)))*y(1)+y(2)*((1-params(22))*QK__+y(6)*params(10)/y(2))-y(3))+params(21)*(y(2)*QK__+y(13)*y(1));
residual(9)= lhs-rhs;
lhs =y(6);
rhs =T153*T159;
residual(10)= lhs-rhs;
lhs =y(20);
rhs =y(6)*(1-y(17))-y(7);
residual(11)= lhs-rhs;
lhs =y(18);
rhs =(params(11)+(1-params(11))*(params(24)+y(23)))/y(13);
residual(12)= lhs-rhs;
lhs =y(19);
rhs =T75;
residual(13)= lhs-rhs;
lhs =log(y(16));
rhs =params(16)*log(y(4))+params(17)*x(it_, 1);
residual(14)= lhs-rhs;
lhs =log(y(17));
rhs =(1-params(18))*log(params(15))+params(18)*log(y(5))+params(19)*x(it_, 2);
residual(15)= lhs-rhs;
if nargout >= 2,
  g1 = zeros(15, 27);

  %
  % Jacobian matrix
  %

  g1(1,7)=y(12)*params(8)/y(22);
  g1(1,22)=y(12)*(-(params(8)*y(7)))/(y(22)*y(22));
  g1(1,12)=params(8)*y(7)/y(22);
  g1(2,6)=Omega__*(-(T55*T197))/(QK__*QK__);
  g1(2,21)=Omega__*((1-params(22))*params(26)*(1-params(12))*(1-y(25))/y(10)*T228*T231+params(10)/y(10))/QK__;
  g1(2,7)=T58*T240+Omega__*(-(T55*T244))/(QK__*QK__);
  g1(2,22)=T58*T286+Omega__*(1-params(22))*T231*params(26)*(1-params(12))*T228*(-1)/y(10)/QK__;
  g1(2,2)=Omega__*(-(T55*T325))/(QK__*QK__);
  g1(2,10)=Omega__*((1-params(22))*T231*params(26)*(1-params(12))*T228*(-(y(21)*(1-y(25))-y(22)))/(y(10)*y(10))+(-(y(21)*params(10)))/(y(10)*y(10)))/QK__;
  g1(2,12)=(-Omega__);
  g1(2,24)=T58*params(8)*y(7)/y(22)*params(9);
  g1(2,15)=(-(params(20)*params(29)));
  g1(2,17)=Omega__*(-(T55*T447))/(QK__*QK__);
  g1(2,25)=Omega__*(1-params(22))*T231*params(26)*(1-params(12))*T228*(-y(21))/y(10)/QK__;
  g1(3,7)=T75*T240;
  g1(3,22)=T75*T286;
  g1(3,12)=(-Omega__);
  g1(3,13)=Omega__*(-(params(11)+(1-params(11))*(params(24)+y(23))))/(y(13)*y(13));
  g1(3,23)=Omega__*(1-params(11))/y(13);
  g1(3,24)=T75*params(8)*y(7)/y(22)*params(9);
  g1(3,15)=(-params(20));
  g1(4,7)=(-(y(12)*T240/(1-y(15))));
  g1(4,22)=(-(y(12)*T286/(1-y(15))));
  g1(4,12)=(-(Omega__/(1-y(15))));
  g1(4,14)=1;
  g1(4,24)=(-(y(12)*params(8)*y(7)/y(22)*params(9)/(1-y(15))));
  g1(4,15)=(-(y(12)*Omega__/((1-y(15))*(1-y(15)))));
  g1(5,6)=(-(y(12)*Omega__*y(8)*params(20)*y(10)*params(29)*T197))/T208;
  g1(5,7)=(params(20)*(y(10)*QK__*params(29)+y(13)*y(9))*y(8)*y(12)*T240-y(12)*Omega__*y(8)*params(20)*y(10)*params(29)*T244)/T208;
  g1(5,22)=y(8)*y(12)*T286/(params(20)*(y(10)*QK__*params(29)+y(13)*y(9)));
  g1(5,8)=y(12)*Omega__/(params(20)*(y(10)*QK__*params(29)+y(13)*y(9)));
  g1(5,9)=(-(y(12)*Omega__*y(8)*params(20)*y(13)))/T208;
  g1(5,2)=(-(y(12)*Omega__*y(8)*params(20)*y(10)*params(29)*T325))/T208;
  g1(5,10)=(-(y(12)*Omega__*y(8)*params(20)*QK__*params(29)))/T208;
  g1(5,12)=Omega__*y(8)/(params(20)*(y(10)*QK__*params(29)+y(13)*y(9)));
  g1(5,13)=(-(y(12)*Omega__*y(8)*params(20)*y(9)))/T208;
  g1(5,24)=y(8)*y(12)*params(8)*y(7)/y(22)*params(9)/(params(20)*(y(10)*QK__*params(29)+y(13)*y(9)));
  g1(5,15)=1;
  g1(5,17)=(-(y(12)*Omega__*y(8)*params(20)*y(10)*params(29)*T447))/T208;
  g1(6,2)=(-(1-params(22)+T101+y(2)*params(26)*(-y(20))/(y(2)*y(2))*T339));
  g1(6,10)=1;
  g1(6,20)=(-(y(2)*params(26)*T339*1/y(2)));
  g1(7,6)=(-(y(17)*(1-params(28))/y(13)));
  g1(7,1)=(-((params(11)+(1-params(11))*(params(24)+y(13))-params(13))/y(13)));
  g1(7,9)=1;
  g1(7,13)=(-((y(13)*(1-params(11))*y(1)-((params(11)+(1-params(11))*(params(24)+y(13)))*y(1)+y(17)*y(6)*(1-params(28))-(params(25)+y(1)*params(13))))/(y(13)*y(13))));
  g1(7,17)=(-(y(6)*(1-params(28))/y(13)));
  g1(8,6)=(-(y(12)*y(10)*T197));
  g1(8,7)=(-(y(12)*y(10)*T244));
  g1(8,8)=y(12);
  g1(8,9)=(-(y(12)*y(13)));
  g1(8,2)=(-(y(12)*y(10)*T325));
  g1(8,10)=(-(y(12)*QK__));
  g1(8,11)=1;
  g1(8,12)=(-(y(13)*y(9)+y(10)*QK__-y(8)));
  g1(8,13)=(-(y(12)*y(9)));
  g1(8,17)=(-(y(12)*y(10)*T447));
  g1(9,6)=(-(params(9)*y(2)*((1-params(22))*T197+params(10)/y(2))+params(21)*y(2)*T197));
  g1(9,7)=(-(params(9)*y(2)*(1-params(22))*T244+params(21)*y(2)*T244));
  g1(9,8)=1;
  g1(9,1)=(-(params(9)*(params(11)+(1-params(11))*(params(24)+y(13)))+y(13)*params(21)));
  g1(9,2)=(-(params(9)*((1-params(22))*QK__+y(6)*params(10)/y(2)+y(2)*((1-params(22))*T325+(-(y(6)*params(10)))/(y(2)*y(2))))+params(21)*(QK__+y(2)*T325)));
  g1(9,3)=params(9);
  g1(9,13)=(-(params(9)*(1-params(11))*y(1)+y(1)*params(21)));
  g1(9,17)=(-(params(9)*y(2)*(1-params(22))*T447+params(21)*y(2)*T447));
  g1(10,6)=1;
  g1(10,7)=(-(T153*(-((1-params(10))*params(23)))/(y(7)*params(23)*y(7)*params(23))*getPowerDeriv((1-params(10))/(y(7)*params(23)),(1-params(10))/(params(10)+params(14)),1)));
  g1(10,2)=(-(T159*T146*T361));
  g1(10,16)=(-(T159*T361*y(2)*getPowerDeriv(y(16),1/params(10),1)));
  g1(11,6)=(-(1-y(17)));
  g1(11,7)=1;
  g1(11,17)=y(6);
  g1(11,20)=1;
  g1(12,13)=(-((-(params(11)+(1-params(11))*(params(24)+y(23))))/(y(13)*y(13))));
  g1(12,23)=(-((1-params(11))/y(13)));
  g1(12,18)=1;
  g1(13,12)=1;
  g1(13,13)=(-((-(params(11)+(1-params(11))*(params(24)+y(23))))/(y(13)*y(13))));
  g1(13,23)=(-((1-params(11))/y(13)));
  g1(13,19)=1;
  g1(14,4)=(-(params(16)*1/y(4)));
  g1(14,16)=1/y(16);
  g1(14,26)=(-params(17));
  g1(15,5)=(-(params(18)*1/y(5)));
  g1(15,17)=1/y(17);
  g1(15,27)=(-params(19));
end
if nargout >= 3,
  %
  % Hessian matrix
  %

  g2 = sparse([],[],[],15,729);
end
if nargout >= 4,
  %
  % Third order derivatives
  %

  g3 = sparse([],[],[],15,19683);
end
end

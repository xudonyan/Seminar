function [ys,check] = mylinear_steadystate(ys,exo)
% function [ys,check] = alpha_steadystate(ys,exo)
% computes the steady state for the alpha.mod and uses a numerical
% solver to do so
% Inputs: 
%   - ys        [vector] vector of initial values for the steady state of
%                   the endogenous variables
%   - exo       [vector] vector of values for the exogenous variables
%
% Output: 
%   - ys        [vector] vector of steady state values fpr the the endogenous variables
%   - check     [scalar] set to 0 if steady state computation worked and to
%                    1 of not (allows to impos restriction on parameters)

global M_   

% read out parameters to access them with their name
NumberOfParameters = M_.param_nbr;
for ii = 1:NumberOfParameters
  paramname = deblank(M_.param_names(ii,:));
  eval([ paramname ' = M_.params(' int2str(ii) ');']);
end
% initialize indicator
check = 0;

%% 
Rss=1/0.99;
delta=0.025;
RBss=1/0.99+0.00435;
kbs=0.5/0.435;
lev=3;
lss=1/3;
bgy=0.135;
beta=1/Rss; 
gamma=1;

psi=0.96;
alpha=0.5;
Pi=0.05;
xi=0.42;

gamma_tau=1;
nu=1/3;
gss=0.197;
gamma_g=0.0;

rho_z=0.74;
sigma_z=0.0054;
rho_g=0.71;
sigma_g=0.016;


%
deltaz=1;
g=gss;
R=Rss;
QB=1;

%%
x0=[40;0.6];
[xx,fval]=fsolve(@dss,x0,optimoptions('fsolve','TolFun',1e-15, 'MaxIter', 1e6),alpha,lss,gss,nu,lev,psi,bgy,Rss,delta,R,kbs,RBss);
K=xx(1);
lambda=xx(2);

N=(bgy/(1-bgy)*K+K)/lev;
alphaS=lambda*(kbs*K+lev*N*bgy  )/N;
Omega=(1-psi+psi*alphaS)/R;
mu=1-Omega*R/alphaS;

y=lss^(1-alpha)*K^alpha;
kai=(1-alpha)/lss^(1+nu)/(1-gss-delta*K/y);
%y=(( kai^( (alpha-1)/(alpha+1/nu )   )* (K/exp(gamma))^(alpha*(( 1+(1-alpha)/(alpha+1/nu)  ) )  ) )/(1-gss-iy)^((1-alpha)/(alpha+1/nu)))^(1/( 1+(1-alpha)/(alpha+1/nu)  ));
c=(1-gss-delta*K/y)*y;
B=bgy/(1-bgy)*K;
P=R*(K+B-N);

%ita=( lambda*muss*Rss/(1-psi+psi*alphaS)-pi) /(1-pi)-1;         %QB=1
ita=( lambda*mu*Rss/(1-psi+psi*alphaS)+R-Pi) /(1-Pi)-1;         %QB=1
tss=-B*( 1-( Pi+(1+ita)*(1-Pi)) ) +(1-gamma_g)*gss*y-gamma_tau*B; %B
omega=(N-psi*(( (1-delta)+alpha*y/K   )*K+ ( Pi+(1-Pi)*(ita+1  ) )*B-P  )) /( (K+B) ); %N
a1=(( y*(1-g)-c )/K  )^(xi)/(1-xi);
a2=delta-a1*(( y*(1-g)-c )/K  )^(1-xi);
QK=(a1*(1-xi)*(( y*(1-g)-c )/K  )^(-xi))^(-1);

RB=( Pi+(1-Pi)*(ita+QB ) )/QB;
RBs=( Pi+(1-Pi)*(ita+QB ) )/QB -R ;
I=( y*(1-g)-c );


%% 

for iter = 1:length(M_.params) %update parameters set in the file
  eval([ 'M_.params(' num2str(iter) ') = ' M_.param_names(iter,:) ';' ])
end

NumberOfEndogenousVariables = M_.orig_endo_nbr; %auxiliary variables are set automatically
for ii = 1:NumberOfEndogenousVariables
  varname = deblank(M_.endo_names(ii,:));
  eval(['ys(' int2str(ii) ') = ' varname ';']);
end

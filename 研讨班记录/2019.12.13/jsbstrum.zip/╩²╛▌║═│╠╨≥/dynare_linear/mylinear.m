%
% Status : main Dynare file 
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

clear all
tic;
global M_ oo_ options_ ys0_ ex0_ estimation_info
options_ = [];
M_.fname = 'mylinear';
%
% Some global variables initialization
%
global_initialization;
diary off;
diary('mylinear.log');
M_.exo_names = 'e_z';
M_.exo_names_tex = 'e\_z';
M_.exo_names_long = 'e_z';
M_.exo_names = char(M_.exo_names, 'e_g');
M_.exo_names_tex = char(M_.exo_names_tex, 'e\_g');
M_.exo_names_long = char(M_.exo_names_long, 'e_g');
M_.endo_names = 'y';
M_.endo_names_tex = 'y';
M_.endo_names_long = 'y';
M_.endo_names = char(M_.endo_names, 'c');
M_.endo_names_tex = char(M_.endo_names_tex, 'c');
M_.endo_names_long = char(M_.endo_names_long, 'c');
M_.endo_names = char(M_.endo_names, 'N');
M_.endo_names_tex = char(M_.endo_names_tex, 'N');
M_.endo_names_long = char(M_.endo_names_long, 'N');
M_.endo_names = char(M_.endo_names, 'B');
M_.endo_names_tex = char(M_.endo_names_tex, 'B');
M_.endo_names_long = char(M_.endo_names_long, 'B');
M_.endo_names = char(M_.endo_names, 'K');
M_.endo_names_tex = char(M_.endo_names_tex, 'K');
M_.endo_names_long = char(M_.endo_names_long, 'K');
M_.endo_names = char(M_.endo_names, 'P');
M_.endo_names_tex = char(M_.endo_names_tex, 'P');
M_.endo_names_long = char(M_.endo_names_long, 'P');
M_.endo_names = char(M_.endo_names, 'R');
M_.endo_names_tex = char(M_.endo_names_tex, 'R');
M_.endo_names_long = char(M_.endo_names_long, 'R');
M_.endo_names = char(M_.endo_names, 'QB');
M_.endo_names_tex = char(M_.endo_names_tex, 'QB');
M_.endo_names_long = char(M_.endo_names_long, 'QB');
M_.endo_names = char(M_.endo_names, 'alphaS');
M_.endo_names_tex = char(M_.endo_names_tex, 'alphaS');
M_.endo_names_long = char(M_.endo_names_long, 'alphaS');
M_.endo_names = char(M_.endo_names, 'mu');
M_.endo_names_tex = char(M_.endo_names_tex, 'mu');
M_.endo_names_long = char(M_.endo_names_long, 'mu');
M_.endo_names = char(M_.endo_names, 'deltaz');
M_.endo_names_tex = char(M_.endo_names_tex, 'deltaz');
M_.endo_names_long = char(M_.endo_names_long, 'deltaz');
M_.endo_names = char(M_.endo_names, 'g');
M_.endo_names_tex = char(M_.endo_names_tex, 'g');
M_.endo_names_long = char(M_.endo_names_long, 'g');
M_.endo_names = char(M_.endo_names, 'RB');
M_.endo_names_tex = char(M_.endo_names_tex, 'RB');
M_.endo_names_long = char(M_.endo_names_long, 'RB');
M_.endo_names = char(M_.endo_names, 'RBs');
M_.endo_names_tex = char(M_.endo_names_tex, 'RBs');
M_.endo_names_long = char(M_.endo_names_long, 'RBs');
M_.endo_names = char(M_.endo_names, 'I');
M_.endo_names_tex = char(M_.endo_names_tex, 'I');
M_.endo_names_long = char(M_.endo_names_long, 'I');
M_.param_names = 'Rss';
M_.param_names_tex = 'Rss';
M_.param_names_long = 'Rss';
M_.param_names = char(M_.param_names, 'iy');
M_.param_names_tex = char(M_.param_names_tex, 'iy');
M_.param_names_long = char(M_.param_names_long, 'iy');
M_.param_names = char(M_.param_names, 'RBss');
M_.param_names_tex = char(M_.param_names_tex, 'RBss');
M_.param_names_long = char(M_.param_names_long, 'RBss');
M_.param_names = char(M_.param_names, 'lev');
M_.param_names_tex = char(M_.param_names_tex, 'lev');
M_.param_names_long = char(M_.param_names_long, 'lev');
M_.param_names = char(M_.param_names, 'lss');
M_.param_names_tex = char(M_.param_names_tex, 'lss');
M_.param_names_long = char(M_.param_names_long, 'lss');
M_.param_names = char(M_.param_names, 'bgy');
M_.param_names_tex = char(M_.param_names_tex, 'bgy');
M_.param_names_long = char(M_.param_names_long, 'bgy');
M_.param_names = char(M_.param_names, 'gamma');
M_.param_names_tex = char(M_.param_names_tex, 'gamma');
M_.param_names_long = char(M_.param_names_long, 'gamma');
M_.param_names = char(M_.param_names, 'beta');
M_.param_names_tex = char(M_.param_names_tex, 'beta');
M_.param_names_long = char(M_.param_names_long, 'beta');
M_.param_names = char(M_.param_names, 'psi');
M_.param_names_tex = char(M_.param_names_tex, 'psi');
M_.param_names_long = char(M_.param_names_long, 'psi');
M_.param_names = char(M_.param_names, 'alpha');
M_.param_names_tex = char(M_.param_names_tex, 'alpha');
M_.param_names_long = char(M_.param_names_long, 'alpha');
M_.param_names = char(M_.param_names, 'Pi');
M_.param_names_tex = char(M_.param_names_tex, 'Pi');
M_.param_names_long = char(M_.param_names_long, 'Pi');
M_.param_names = char(M_.param_names, 'xi');
M_.param_names_tex = char(M_.param_names_tex, 'xi');
M_.param_names_long = char(M_.param_names_long, 'xi');
M_.param_names = char(M_.param_names, 'gamma_tau');
M_.param_names_tex = char(M_.param_names_tex, 'gamma\_tau');
M_.param_names_long = char(M_.param_names_long, 'gamma_tau');
M_.param_names = char(M_.param_names, 'nu');
M_.param_names_tex = char(M_.param_names_tex, 'nu');
M_.param_names_long = char(M_.param_names_long, 'nu');
M_.param_names = char(M_.param_names, 'gss');
M_.param_names_tex = char(M_.param_names_tex, 'gss');
M_.param_names_long = char(M_.param_names_long, 'gss');
M_.param_names = char(M_.param_names, 'rho_z');
M_.param_names_tex = char(M_.param_names_tex, 'rho\_z');
M_.param_names_long = char(M_.param_names_long, 'rho_z');
M_.param_names = char(M_.param_names, 'sigma_z');
M_.param_names_tex = char(M_.param_names_tex, 'sigma\_z');
M_.param_names_long = char(M_.param_names_long, 'sigma_z');
M_.param_names = char(M_.param_names, 'rho_g');
M_.param_names_tex = char(M_.param_names_tex, 'rho\_g');
M_.param_names_long = char(M_.param_names_long, 'rho_g');
M_.param_names = char(M_.param_names, 'sigma_g');
M_.param_names_tex = char(M_.param_names_tex, 'sigma\_g');
M_.param_names_long = char(M_.param_names_long, 'sigma_g');
M_.param_names = char(M_.param_names, 'lambda');
M_.param_names_tex = char(M_.param_names_tex, 'lambda');
M_.param_names_long = char(M_.param_names_long, 'lambda');
M_.param_names = char(M_.param_names, 'omega');
M_.param_names_tex = char(M_.param_names_tex, 'omega');
M_.param_names_long = char(M_.param_names_long, 'omega');
M_.param_names = char(M_.param_names, 'delta');
M_.param_names_tex = char(M_.param_names_tex, 'delta');
M_.param_names_long = char(M_.param_names_long, 'delta');
M_.param_names = char(M_.param_names, 'kai');
M_.param_names_tex = char(M_.param_names_tex, 'kai');
M_.param_names_long = char(M_.param_names_long, 'kai');
M_.param_names = char(M_.param_names, 'ita');
M_.param_names_tex = char(M_.param_names_tex, 'ita');
M_.param_names_long = char(M_.param_names_long, 'ita');
M_.param_names = char(M_.param_names, 'tss');
M_.param_names_tex = char(M_.param_names_tex, 'tss');
M_.param_names_long = char(M_.param_names_long, 'tss');
M_.param_names = char(M_.param_names, 'a1');
M_.param_names_tex = char(M_.param_names_tex, 'a1');
M_.param_names_long = char(M_.param_names_long, 'a1');
M_.param_names = char(M_.param_names, 'a2');
M_.param_names_tex = char(M_.param_names_tex, 'a2');
M_.param_names_long = char(M_.param_names_long, 'a2');
M_.param_names = char(M_.param_names, 'gamma_g');
M_.param_names_tex = char(M_.param_names_tex, 'gamma\_g');
M_.param_names_long = char(M_.param_names_long, 'gamma_g');
M_.param_names = char(M_.param_names, 'kbs');
M_.param_names_tex = char(M_.param_names_tex, 'kbs');
M_.param_names_long = char(M_.param_names_long, 'kbs');
M_.exo_det_nbr = 0;
M_.exo_nbr = 2;
M_.endo_nbr = 15;
M_.param_nbr = 29;
M_.orig_endo_nbr = 15;
M_.aux_vars = [];
M_.Sigma_e = zeros(2, 2);
M_.Correlation_matrix = eye(2, 2);
M_.H = 0;
M_.Correlation_matrix_ME = 1;
M_.sigma_e_is_diagonal = 1;
options_.block=0;
options_.bytecode=0;
options_.use_dll=0;
erase_compiled_function('mylinear_static');
erase_compiled_function('mylinear_dynamic');
M_.lead_lag_incidence = [
 0 6 21;
 0 7 22;
 0 8 0;
 1 9 0;
 2 10 0;
 3 11 0;
 0 12 0;
 0 13 23;
 0 14 24;
 0 15 0;
 4 16 0;
 5 17 25;
 0 18 0;
 0 19 0;
 0 20 0;]';
M_.nstatic = 6;
M_.nfwrd   = 4;
M_.npred   = 4;
M_.nboth   = 1;
M_.nsfwrd   = 5;
M_.nspred   = 5;
M_.ndynamic   = 9;
M_.equations_tags = {
};
M_.static_and_dynamic_models_differ = 0;
M_.exo_names_orig_ord = [1:2];
M_.maximum_lag = 1;
M_.maximum_lead = 1;
M_.maximum_endo_lag = 1;
M_.maximum_endo_lead = 1;
oo_.steady_state = zeros(15, 1);
M_.maximum_exo_lag = 0;
M_.maximum_exo_lead = 0;
oo_.exo_steady_state = zeros(2, 1);
M_.params = NaN(29, 1);
M_.NNZDerivatives = zeros(3, 1);
M_.NNZDerivatives(1) = 86;
M_.NNZDerivatives(2) = -1;
M_.NNZDerivatives(3) = -1;
M_.params( 1 ) = 1.01010101010101;
Rss = M_.params( 1 );
M_.params( 22 ) = 0.025;
delta = M_.params( 22 );
M_.params( 3 ) = 1.01445101010101;
RBss = M_.params( 3 );
M_.params( 29 ) = 1.149425287356322;
kbs = M_.params( 29 );
M_.params( 4 ) = 3;
lev = M_.params( 4 );
M_.params( 5 ) = 0.3333333333333333;
lss = M_.params( 5 );
M_.params( 6 ) = 0.135;
bgy = M_.params( 6 );
M_.params( 8 ) = 1/M_.params(1);
beta = M_.params( 8 );
M_.params( 7 ) = 1;
gamma = M_.params( 7 );
M_.params( 9 ) = 0.96;
psi = M_.params( 9 );
M_.params( 10 ) = 0.5;
alpha = M_.params( 10 );
M_.params( 11 ) = 0.05;
Pi = M_.params( 11 );
M_.params( 12 ) = 0.42;
xi = M_.params( 12 );
M_.params( 13 ) = 1;
gamma_tau = M_.params( 13 );
M_.params( 14 ) = 0.3333333333333333;
nu = M_.params( 14 );
M_.params( 15 ) = 0.197;
gss = M_.params( 15 );
M_.params( 28 ) = 0.0;
gamma_g = M_.params( 28 );
M_.params( 16 ) = 0.74;
rho_z = M_.params( 16 );
M_.params( 17 ) = 0.0054;
sigma_z = M_.params( 17 );
M_.params( 18 ) = 0.71;
rho_g = M_.params( 18 );
M_.params( 19 ) = 0.016;
sigma_g = M_.params( 19 );
%
% SHOCKS instructions
%
make_ex_;
M_.exo_det_length = 0;
M_.Sigma_e(1, 1) = (1)^2;
M_.Sigma_e(2, 2) = (1)^2;
steady;
oo_.dr.eigval = check(M_,options_,oo_);
options_.irf = 50;
options_.nograph = 1;
options_.order = 1;
var_list_=[];
info = stoch_simul(var_list_);
cd ..
Kb=[oo_.dr.ys(5)  oo_.dr.ghx(8,2)  oo_.dr.ghx(8,1)  oo_.dr.ghx(8,3)  oo_.dr.ghu(6,1)  oo_.dr.ghu(6,2) ];
Bb=[oo_.dr.ys(4)  oo_.dr.ghx(7,2)  oo_.dr.ghx(7,1)  oo_.dr.ghx(7,3)  oo_.dr.ghu(7,1)  oo_.dr.ghu(7,2)  ];
Ab=[oo_.dr.ys(9)  oo_.dr.ghx(15,2)  oo_.dr.ghx(15,1)  oo_.dr.ghx(15,3)  oo_.dr.ghu(15,1)  oo_.dr.ghu(15,2) ];
Pb=[oo_.dr.ys(6)  oo_.dr.ghx(9,2)  oo_.dr.ghx(9,1)  oo_.dr.ghx(9,3)  oo_.dr.ghu(9,1)  oo_.dr.ghu(9,2)];
save mat/Kb Kb;
save mat/Bb Bb;
save mat/Pb Pb;
save mat/Ab Ab;
oo_var=oo_.var;
save mat/oo_var oo_var;
oo_steady_state=oo_.steady_state;
save mat/oo_steady_state  oo_steady_state;
M_params=M_.params;
save mat/M_params M_params;
save('mylinear_results.mat', 'oo_', 'M_', 'options_');
if exist('estim_params_', 'var') == 1
  save('mylinear_results.mat', 'estim_params_', '-append');
end
if exist('bayestopt_', 'var') == 1
  save('mylinear_results.mat', 'bayestopt_', '-append');
end
if exist('dataset_', 'var') == 1
  save('mylinear_results.mat', 'dataset_', '-append');
end
if exist('estimation_info', 'var') == 1
  save('mylinear_results.mat', 'estimation_info', '-append');
end


disp(['Total computing time : ' dynsec2hms(toc) ]);
if ~isempty(lastwarn)
  disp('Note: warning(s) encountered in MATLAB/Octave code')
end
diary off

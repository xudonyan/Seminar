%========================================================
%     main.m MATLAB program to replicate the  paper 
%
%     �ط�����ծ���������ڲ��ŷ��յġ�˫�������ṹ�������ڷ�����DSGEģ�͵ķ���
%
%     December  2018
%
%     Written by Chen Xiong
%
%     using iterative (fxed points) methods
%
%========================================================

% -----------------------------------------
% 0. linear solution���²��
clear
clear all;
cd dynare_linear
dynare mylinear


% -----------------------------------------
clear
clear all;
path('model_tools',path);
path('mat',path);
path('general_tools',path);
global Rss  RBss   lev  lss  bgy  gamma beta  psi  alpha   Pi  xi gamma_tau  nu gss rho_z sigma_z rho_g sigma_g  lambda  omega delta kai ita tss a1  a2 ;
global po_K po_B po_P po_z po_g  Knod Bnod Pnod znod gnod  zmin gmin  Kmin Bmin Pmin zmax gmax Kmax  Bmax Pmax;
global maxiter psitol dimgrid gamma_g sss    rho_s sigma_s  smin   smax po_s snod D kappa kbs;

% 1. ����
% ========================================================

% 1.1 ģ�Ͳ���
% -------------------------------------------------------------------------
%target
Rss=1/0.99;
delta=0.025;
RBss=1/0.99+0.00435;
kbs=0.5/0.435;
lev=3;
lss=1/3;
bgy=0.135;
beta=1/Rss; 
gamma=1;

psi=0.96;
alpha=0.5;
Pi=0.05;
xi=0.42;

gamma_tau=1;
nu=1/3;
gss=0.197;
gamma_g=0.0;

rho_z=0.74;
sigma_z=0.0054;
rho_g=0.71;
sigma_g=0.016;

rho_s=0.95;
sigma_s=0.33;
D=0.0978;
kappa=70;
sss=-5.2;

load M_params
load oo_steady_state
load oo_var

lambda=M_params(20);
omega=M_params(21);
delta =M_params(22);
kai=M_params(23); 
ita=M_params(24); 
tss=M_params(25); 
a1=M_params(26);  
a2=M_params(27);

% 1.2 �㷨��ز���
% -------------------------------------------------------------------------
po_K    =  2;                 
po_B    =  2;                
po_P    =  2;                 
po_z    =  2;               
po_g    =  2;                
po_s    =2;

Knod    =  3;         
Bnod    = 3;         
Pnod    =  3;        
znod    =  3;          
gnod    =  3;        
snod    =3;

zmin   =-3; 
zmax   = 3;  

gmin   =-3;  
gmax   = 3;  

smin    = sss-2;       
smax    = sss+2.7;      

Kmin   =-4;  
Kmax   = 4 ; 

Bmin   =-6 ; 
Bmax   = 6;  

Pmin   =-4;  
Pmax   = 4;  

maxiter= 2000;       % Maximum Iterations 
psitol   = 1e-6;       % Convergence criterion
lrate   = 0.5;           % parameter to control updating of new projection coefficient


% 1.3 ���ڷ������̬����ΥԼģ�ͣ�����״̬�ռ�
%       
% -------------------------------------------------------------------------

% Steady state
Kss=oo_steady_state(5);
Bss=oo_steady_state(4);
Pss=oo_steady_state(6);
sdK=oo_var(5,5)^(1/2);
sdB=oo_var(4,4)^(1/2);
sdP=oo_var(6,6)^(1/2);

% Set for state space
Kmin     = Kss + Kmin*sdK;
Kmax     = Kss + Kmax*sdK;
Bmin     = Bss + Bmin*sdB;
Bmax     = Bss + Bmax*sdB;
Pmin     = Pss + Pmin*sdP;
Pmax     = Pss + Pmax*sdP;
zsig    = sigma_z/sqrt(1-rho_z^2);
gsig    = sigma_g/sqrt(1-rho_g^2);
ssig    = sigma_s/sqrt(1-rho_s^2);
zmin    = exp(zmin*zsig);
zmax    = exp(zmax*zsig);
gmin     =exp(log(gss) + gmin*gsig);
gmax     =exp(log(gss) + gmax*gsig);
smin     =exp(smin);
smax     =exp( smax);


% *****************************************************************************************
%                                      Main   Program                     
% *****************************************************************************************

% 2 ���ߺ����Ĳ�����
% =======================================================

% 2.1 �б�ѩ����
% ------------------------------------------------------------------------

Kg      = chebnode(Knod);
Bg      = chebnode(Bnod);
Pg      = chebnode(Pnod);
zg      = chebnode(znod);
gg     = chebnode(gnod);
sg      = chebnode(snod);

for Ki  = 1:Knod;
	for Bi  = 1:Bnod;
        for PPi=1:Pnod
            for zi=1:znod
                for gi=1:gnod
                    for si=1:snod
		xgrid((Ki-1)*Bnod*Pnod*znod*gnod*snod+(Bi-1)*Pnod*znod*gnod*snod+(PPi-1)*znod*gnod*snod+(zi-1)*gnod*snod+(gi-1)*snod+si,:) = [Kg(Ki) Bg(Bi) Pg(PPi) zg(zi) gg(gi) sg(si)];
                    end 
                end
            end
        end
	end;
end;

[dimgrid nvars] = size(xgrid);

% 2.2 ͶӰ�����б�ѩ�����ʽ
% --------------------------------
Yvec    = zeros(dimgrid,8);                        
xmat  = makepoly([po_K po_B po_P po_z po_g po_s],xgrid);
xr      = inv(xmat'*xmat)*xmat';            

% 2.3 ��ʼ�²�⣬ʹ������Dynare �õ������ߺ���ͶӰ
% ------------------------------------------------------------------------

% 2.3.1 
% -----------------------------------------
psisize = (po_K+1)*(po_B+1)*(po_P+1)*(po_z+1)*(po_g+1)*(po_s+1);
PsiN_K     = zeros(psisize,1);      % parameters for no default
PsiN_B     = zeros(psisize,1);      % parameters for no default
PsiN_P    = zeros(psisize,1);      % parameters for no default
PsiN_A     = zeros(psisize,1);      % parameters for no default
PsiD_K     = zeros(psisize,1);      % parametres for  default
PsiD_B     = zeros(psisize,1);      % parametres for default
PsiD_P     = zeros(psisize,1);      % parametres for  default
PsiD_A     = zeros(psisize,1);      % parametres for  default

% 2.3.2. Compute and Load the file 
% -----------------------------------------
% -----------------------------------------
% linear solution ,���Խ�
% Compute solution

% load Kb
% load Bb
% load Pb
% load Ab
% ss=[ones(dimgrid,1)  scalup(xgrid(:,1),Kmin,Kmax)-Kss*ones(dimgrid,1)  scalup(xgrid(:,2),Bmin,Bmax)-Bss*ones(dimgrid,1)  scalup(xgrid(:,3),Pmin,Pmax)-Pss*ones(dimgrid,1)   scalup(xgrid(:,4),zmin,zmax)-ones(dimgrid,1)  scalup(xgrid(:,5),gmin,gmax)-gss*ones(dimgrid,1)   ];
% K_initial=ss*Kb';
% B_initial=ss*Bb';
% P_initial=ss*Pb';
% A_initial=ss*Ab';
% % Projection
% PsiN_K   = xr*K_initial;
% PsiN_B    = xr*B_initial;
% PsiN_P    = xr*P_initial;
% PsiN_A    = xr*A_initial;
% PsiD_K     =PsiN_K ;   
% PsiD_B    =PsiN_B;      
% PsiD_P     =PsiN_P  ;    
% PsiD_A    =PsiN_A ;   

% ֱ�Ӵ��������Ľ��
% -----------------------------------------
load PPsi
PsiN_K   = PPsi(:,1);
PsiN_B   = PPsi(:,2);
PsiN_P   = PPsi(:,3);
PsiN_A   = PPsi(:,4);
PsiD_K   = PPsi(:,5);
PsiD_B   = PPsi(:,6);
PsiD_P   = PPsi(:,7);
PsiD_A   = PPsi(:,8);

% =======================================================
% 3 The Main Loop
% =======================================================
% diary('solve.text')

% First, given state
K1      = scalup(xgrid(:,1),Kmin,Kmax);    
B1      = scalup(xgrid(:,2),Bmin,Bmax);    
P1      = scalup(xgrid(:,3),Pmin,Pmax);        
z1      = scalup(xgrid(:,4),zmin,zmax);       
g1      = scalup(xgrid(:,5),gmin,gmax);    
s1      = scalup(xgrid(:,6),smin,smax);    

xmat_uns       =xmat;

z2=exp(sigma_z^2/2)*(z1.^rho_z);
g2=(gss^(1-rho_g))*exp(sigma_g^2/2)*(g1.^rho_g);

for psiter      = 1:maxiter;   

tic
[ C1_d0, R1_d0 , A1_d0,  Q1_d0 , y1_d0, QK1_d0, N1_d0, K2_d0, B2_d0, P2_d0 ,C1_d1, R1_d1,  A1_d1,  Q1_d1,  y1_d1, QK1_d1, N1_d1, K2_d1, B2_d1, P2_d1]=solve_equilibrium(xmat_uns,K1,B1,P1, z1, g1, s1, PsiN_K,PsiN_B,PsiN_P,PsiN_A,PsiD_K,PsiD_B,PsiD_P,PsiD_A);

[Yvec, PsiN_ER3,PsiN_EQ, PsiD_ER3,PsiD_EQ]= feval(@projec_exp,z2,g2,z1,g1,s1,K2_d0,B2_d0,P2_d0, K2_d1,B2_d1,P2_d1,...
 C1_d0,C1_d1,R1_d0,R1_d1,N1_d0,N1_d1,QK1_d0,QK1_d1,Q1_d0,Q1_d1, A1_d0, A1_d1, y1_d0 ,y1_d1,  xr, K1,B1,P1, Yvec);
toc

PsiN_K_n    = xr*Yvec(:,1);
PsiN_B_n    =  xr*Yvec(:,2);
PsiN_P_n     =  xr*Yvec(:,3);
PsiN_A_n     =  xr*Yvec(:,4);
PsiD_K_n      = xr*Yvec(:,5);
PsiD_B_n     = xr*Yvec(:,6);
PsiD_P_n      = xr*Yvec(:,7);
PsiD_A_n      = xr*Yvec(:,8);
delPsiN_K    = norm(PsiN_K-PsiN_K_n );
delPsiN_B    =  norm(PsiN_B-PsiN_B_n );
delPsiN_P    = norm(PsiN_P-PsiN_P_n );
delPsiN_A    =  norm(PsiN_A-PsiN_A_n );
delPsiD_K     = norm(PsiD_K-PsiD_K_n );
delPsiD_B     = norm(PsiD_B-PsiD_B_n );
delPsiD_P     = norm(PsiD_P-PsiD_P_n );
delPsiD_A     = norm(PsiD_A-PsiD_A_n );
s111       = sprintf('After %3.0d iterations the Difference in psi was %6.4d and %6.4d and %6.4d  and %6.4d and  %6.4d and %6.4d and %6.4d  and %6.4d .',psiter,delPsiN_K,delPsiN_B,delPsiN_P,delPsiN_A,delPsiD_K,delPsiD_B,delPsiD_P,delPsiD_A);
	disp(s111)
	if delPsiN_K < psitol &&  delPsiN_B < psitol  &&  delPsiN_P < psitol &&  delPsiN_A < psitol  &&  delPsiD_K < psitol &&  delPsiD_B < psitol &&  delPsiD_P< psitol &&  delPsiD_A< psitol ;
		break;
    else
	   PsiN_K     = lrate*PsiN_K_n+(1-lrate)*PsiN_K;
       PsiN_B     = lrate*PsiN_B_n+(1-lrate)*PsiN_B;
       PsiN_P     = lrate*PsiN_P_n+(1-lrate)*PsiN_P;
       PsiN_A     = lrate*PsiN_A_n+(1-lrate)*PsiN_A;
       PsiD_K     = lrate*PsiD_K_n+(1-lrate)*PsiD_K;
       PsiD_B     = lrate*PsiD_B_n+(1-lrate)*PsiD_B;
       PsiD_P     = lrate*PsiD_P_n+(1-lrate)*PsiD_P;
       PsiD_A     = lrate*PsiD_A_n+(1-lrate)*PsiD_A;
	end;
end;

% =======================================================
% ���ߺ���
PPsi=[ PsiN_K PsiN_B PsiN_P PsiN_A  PsiD_K PsiD_B PsiD_P PsiD_A ];
save mat/PPsi  PPsi;
save mat/PsiN_ER3 PsiN_ER3;
save mat/PsiN_EQ  PsiN_EQ;
save mat/PsiD_ER3 PsiD_ER3;
save mat/PsiD_EQ  PsiD_EQ;

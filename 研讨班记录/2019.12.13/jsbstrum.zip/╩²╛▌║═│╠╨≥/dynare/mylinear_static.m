function [residual, g1, g2] = mylinear_static(y, x, params)
%
% Status : Computes static model for Dynare
%
% Inputs : 
%   y         [M_.endo_nbr by 1] double    vector of endogenous variables in declaration order
%   x         [M_.exo_nbr by 1] double     vector of exogenous variables in declaration order
%   params    [M_.param_nbr by 1] double   vector of parameter values in declaration order
%
% Outputs:
%   residual  [M_.endo_nbr by 1] double    vector of residuals of the static model equations 
%                                          in order of declaration of the equations
%   g1        [M_.endo_nbr by M_.endo_nbr] double    Jacobian matrix of the static model equations;
%                                                     columns: variables in declaration order
%                                                     rows: equations in order of declaration
%   g2        [M_.endo_nbr by (M_.endo_nbr)^2] double   Hessian matrix of the static model equations;
%                                                       columns: variables in declaration order
%                                                       rows: equations in order of declaration
%
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

residual = zeros( 19, 1);

%
% Model equations
%

Omega__ = params(8)*y(2)/y(2)*(1-params(9)+params(9)*y(9));
Lambda__ = params(8)*y(2)/y(2);
QK11__ = (params(26)*(1-params(12))*((y(1)*(1-y(12))-y(2))/y(19))^(-params(12)))^(-1);
QK__ = (params(26)*(1-params(12))*((y(1)*(1-y(12))-y(2))/y(5))^(-params(12)))^(-1);
QK1__ = (params(26)*(1-params(12))*((y(1)*(1-y(12))-y(2))/y(5))^(-params(12)))^(-1);
T50 = (1-params(22))*QK1__+y(1)*params(10)/y(5);
T71 = y(16)*(params(11)+(1-params(11))*(params(24)+y(8)))/y(8)-y(7);
T96 = params(26)*(y(15)/y(5))^(1-params(12))+params(27);
T120 = y(1)*params(10)/y(5)+(1-params(22))*QK__;
T131 = y(11)^(1/params(10));
T138 = (y(5)*T131)^(params(10)*(1+params(14))/(params(10)+params(14)));
T144 = ((1-params(10))/(y(2)*params(23)))^((1-params(10))/(params(10)+params(14)));
T202 = getPowerDeriv((y(1)*(1-y(12))-y(2))/y(5),(-params(12)),1);
T205 = getPowerDeriv(params(26)*(1-params(12))*((y(1)*(1-y(12))-y(2))/y(5))^(-params(12)),(-1),1);
T206 = params(26)*(1-params(12))*(1-y(12))/y(5)*T202*T205;
T209 = (1-params(22))*T206+params(10)/y(5);
T221 = params(20)*(y(5)*QK__*params(34)+y(8)*y(4))*params(20)*(y(5)*QK__*params(34)+y(8)*y(4));
T237 = getPowerDeriv((y(1)*(1-y(12))-y(2))/y(19),(-params(12)),1);
T240 = getPowerDeriv(params(26)*(1-params(12))*((y(1)*(1-y(12))-y(2))/y(19))^(-params(12)),(-1),1);
T252 = T205*params(26)*(1-params(12))*T202*(-1)/y(5);
T313 = T205*params(26)*(1-params(12))*T202*(-(y(1)*(1-y(12))-y(2)))/(y(5)*y(5));
T317 = (1-params(22))*T313+(-(y(1)*params(10)))/(y(5)*y(5));
T333 = getPowerDeriv(y(15)/y(5),1-params(12),1);
T350 = getPowerDeriv(y(5)*T131,params(10)*(1+params(14))/(params(10)+params(14)),1);
T368 = (y(8)*y(16)*(1-params(11))-y(16)*(params(11)+(1-params(11))*(params(24)+y(8))))/(y(8)*y(8));
T414 = T205*params(26)*(1-params(12))*T202*(-y(1))/y(5);
lhs =Lambda__*y(7);
rhs =1;
residual(1)= lhs-rhs;
lhs =Omega__*(T50/QK__-y(7));
rhs =params(20)*params(34)*y(10);
residual(2)= lhs-rhs;
lhs =Omega__*T71;
rhs =params(20)*y(10);
residual(3)= lhs-rhs;
lhs =y(9);
rhs =y(7)*Omega__/(1-y(10));
residual(4)= lhs-rhs;
lhs =y(10);
rhs =1-y(7)*Omega__*y(3)/(params(20)*(y(5)*QK__*params(34)+y(8)*y(4)));
residual(5)= lhs-rhs;
lhs =y(5);
rhs =y(5)*(1-params(22))+y(5)*T96;
residual(6)= lhs-rhs;
lhs =y(4);
rhs =((params(11)+(1-params(11))*(params(24)+y(8)))*y(4)+y(12)*y(1)*(1-params(28))-(params(25)+y(4)*params(13)))/y(8);
residual(7)= lhs-rhs;
lhs =y(6);
rhs =y(7)*(y(8)*y(4)+y(5)*QK__-y(3));
residual(8)= lhs-rhs;
lhs =y(3);
rhs =params(9)*((params(11)+(1-params(11))*(params(24)+y(8)))*y(4)+y(5)*T120-y(6))+(y(8)*y(4)+y(5)*QK__)*params(21);
residual(9)= lhs-rhs;
lhs =y(1);
rhs =T138*T144;
residual(10)= lhs-rhs;
lhs =y(15);
rhs =y(1)*(1-y(12))-y(2);
residual(11)= lhs-rhs;
lhs =y(13);
rhs =y(16)*(params(11)+(1-params(11))*(params(24)+y(8)))/y(8);
residual(12)= lhs-rhs;
lhs =y(14);
rhs =T71;
residual(13)= lhs-rhs;
lhs =log(y(11));
rhs =log(y(11))*params(16)+params(17)*x(1);
residual(14)= lhs-rhs;
lhs =log(y(12));
rhs =(1-params(18))*log(params(15))+log(y(12))*params(18)+params(19)*x(2);
residual(15)= lhs-rhs;
lhs =log(y(17));
rhs =(1-params(30))*params(32)+log(y(17))*params(30)+params(31)*x(3);
residual(16)= lhs-rhs;
lhs =y(16);
rhs =1+y(17)*(1-params(29))/(1+y(17))-y(17)/(1+y(17));
residual(17)= lhs-rhs;
lhs =y(18);
rhs =T120/QK11__;
residual(18)= lhs-rhs;
lhs =y(19);
rhs =y(5);
residual(19)= lhs-rhs;
if ~isreal(residual)
  residual = real(residual)+imag(residual).^2;
end
if nargout >= 2,
  g1 = zeros(19, 19);

  %
  % Jacobian matrix
  %

  g1(1,7)=Lambda__;
  g1(2,1)=Omega__*(QK__*T209-T50*T206)/(QK__*QK__);
  g1(2,2)=Omega__*(QK__*(1-params(22))*T252-T50*T252)/(QK__*QK__);
  g1(2,5)=Omega__*(QK__*T317-T50*T313)/(QK__*QK__);
  g1(2,7)=(-Omega__);
  g1(2,9)=(T50/QK__-y(7))*params(8)*y(2)/y(2)*params(9);
  g1(2,10)=(-(params(20)*params(34)));
  g1(2,12)=Omega__*(QK__*(1-params(22))*T414-T50*T414)/(QK__*QK__);
  g1(3,7)=(-Omega__);
  g1(3,8)=Omega__*T368;
  g1(3,9)=T71*params(8)*y(2)/y(2)*params(9);
  g1(3,10)=(-params(20));
  g1(3,16)=Omega__*(params(11)+(1-params(11))*(params(24)+y(8)))/y(8);
  g1(4,7)=(-(Omega__/(1-y(10))));
  g1(4,9)=1-y(7)*params(8)*y(2)/y(2)*params(9)/(1-y(10));
  g1(4,10)=(-(y(7)*Omega__/((1-y(10))*(1-y(10)))));
  g1(5,1)=(-(y(7)*Omega__*y(3)*params(20)*y(5)*params(34)*T206))/T221;
  g1(5,2)=(-(y(7)*Omega__*y(3)*params(20)*y(5)*params(34)*T252))/T221;
  g1(5,3)=y(7)*Omega__/(params(20)*(y(5)*QK__*params(34)+y(8)*y(4)));
  g1(5,4)=(-(y(7)*Omega__*y(3)*params(20)*y(8)))/T221;
  g1(5,5)=(-(y(7)*Omega__*y(3)*params(20)*(QK__*params(34)+y(5)*params(34)*T313)))/T221;
  g1(5,7)=Omega__*y(3)/(params(20)*(y(5)*QK__*params(34)+y(8)*y(4)));
  g1(5,8)=(-(y(7)*Omega__*y(3)*params(20)*y(4)))/T221;
  g1(5,9)=y(3)*y(7)*params(8)*y(2)/y(2)*params(9)/(params(20)*(y(5)*QK__*params(34)+y(8)*y(4)));
  g1(5,10)=1;
  g1(5,12)=(-(y(7)*Omega__*y(3)*params(20)*y(5)*params(34)*T414))/T221;
  g1(6,5)=1-(1-params(22)+T96+y(5)*params(26)*(-y(15))/(y(5)*y(5))*T333);
  g1(6,15)=(-(y(5)*params(26)*T333*1/y(5)));
  g1(7,1)=(-(y(12)*(1-params(28))/y(8)));
  g1(7,4)=1-(params(11)+(1-params(11))*(params(24)+y(8))-params(13))/y(8);
  g1(7,8)=(-((y(8)*(1-params(11))*y(4)-((params(11)+(1-params(11))*(params(24)+y(8)))*y(4)+y(12)*y(1)*(1-params(28))-(params(25)+y(4)*params(13))))/(y(8)*y(8))));
  g1(7,12)=(-(y(1)*(1-params(28))/y(8)));
  g1(8,1)=(-(y(7)*y(5)*T206));
  g1(8,2)=(-(y(7)*y(5)*T252));
  g1(8,3)=y(7);
  g1(8,4)=(-(y(7)*y(8)));
  g1(8,5)=(-(y(7)*(QK__+y(5)*T313)));
  g1(8,6)=1;
  g1(8,7)=(-(y(8)*y(4)+y(5)*QK__-y(3)));
  g1(8,8)=(-(y(7)*y(4)));
  g1(8,12)=(-(y(7)*y(5)*T414));
  g1(9,1)=(-(params(9)*y(5)*T209+params(21)*y(5)*T206));
  g1(9,2)=(-(params(9)*y(5)*(1-params(22))*T252+params(21)*y(5)*T252));
  g1(9,3)=1;
  g1(9,4)=(-(params(9)*(params(11)+(1-params(11))*(params(24)+y(8)))+y(8)*params(21)));
  g1(9,5)=(-(params(9)*(T120+y(5)*T317)+params(21)*(QK__+y(5)*T313)));
  g1(9,6)=params(9);
  g1(9,8)=(-(params(9)*(1-params(11))*y(4)+y(4)*params(21)));
  g1(9,12)=(-(params(9)*y(5)*(1-params(22))*T414+params(21)*y(5)*T414));
  g1(10,1)=1;
  g1(10,2)=(-(T138*(-((1-params(10))*params(23)))/(y(2)*params(23)*y(2)*params(23))*getPowerDeriv((1-params(10))/(y(2)*params(23)),(1-params(10))/(params(10)+params(14)),1)));
  g1(10,5)=(-(T144*T131*T350));
  g1(10,11)=(-(T144*T350*y(5)*getPowerDeriv(y(11),1/params(10),1)));
  g1(11,1)=(-(1-y(12)));
  g1(11,2)=1;
  g1(11,12)=y(1);
  g1(11,15)=1;
  g1(12,8)=(-T368);
  g1(12,13)=1;
  g1(12,16)=(-((params(11)+(1-params(11))*(params(24)+y(8)))/y(8)));
  g1(13,7)=1;
  g1(13,8)=(-T368);
  g1(13,14)=1;
  g1(13,16)=(-((params(11)+(1-params(11))*(params(24)+y(8)))/y(8)));
  g1(14,11)=1/y(11)-params(16)*1/y(11);
  g1(15,12)=1/y(12)-params(18)*1/y(12);
  g1(16,17)=1/y(17)-params(30)*1/y(17);
  g1(17,16)=1;
  g1(17,17)=(-(((1-params(29))*(1+y(17))-y(17)*(1-params(29)))/((1+y(17))*(1+y(17)))-(1+y(17)-y(17))/((1+y(17))*(1+y(17)))));
  g1(18,1)=(-((QK11__*T209-T120*params(26)*(1-params(12))*(1-y(12))/y(19)*T237*T240)/(QK11__*QK11__)));
  g1(18,2)=(-((QK11__*(1-params(22))*T252-T120*T240*params(26)*(1-params(12))*T237*(-1)/y(19))/(QK11__*QK11__)));
  g1(18,5)=(-(T317/QK11__));
  g1(18,12)=(-((QK11__*(1-params(22))*T414-T120*T240*params(26)*(1-params(12))*T237*(-y(1))/y(19))/(QK11__*QK11__)));
  g1(18,18)=1;
  g1(18,19)=(-((-(T120*T240*params(26)*(1-params(12))*T237*(-(y(1)*(1-y(12))-y(2)))/(y(19)*y(19))))/(QK11__*QK11__)));
  g1(19,5)=(-1);
  g1(19,19)=1;
  if ~isreal(g1)
    g1 = real(g1)+2*imag(g1);
  end
end
if nargout >= 3,
  %
  % Hessian matrix
  %

  g2 = sparse([],[],[],19,361);
end
end

function [ys,check] = mylinear_steadystate(ys,exo)
% function [ys,check] = alpha_steadystate(ys,exo)
% computes the steady state for the alpha.mod and uses a numerical
% solver to do so
% Inputs: 
%   - ys        [vector] vector of initial values for the steady state of
%                   the endogenous variables
%   - exo       [vector] vector of values for the exogenous variables
%
% Output: 
%   - ys        [vector] vector of steady state values fpr the the endogenous variables
%   - check     [scalar] set to 0 if steady state computation worked and to
%                    1 of not (allows to impos restriction on parameters)

global M_   

% read out parameters to access them with their name
NumberOfParameters = M_.param_nbr;
for ii = 1:NumberOfParameters
  paramname = deblank(M_.param_names(ii,:));
  eval([ paramname ' = M_.params(' int2str(ii) ');']);
end
% initialize indicator
check = 0;

%% 
Rss=M_.params(1); 
iy  =M_.params(2); 
RBss =M_.params(3); 
lev  =M_.params(4); 
lss =M_.params(5); 
bgy =M_.params(6);  
gamma =M_.params(7); 
beta  =M_.params(8); 
psi  =M_.params(9); 
alpha=M_.params(10);  
Pi  =M_.params(11); 
xi =M_.params(12); 
gamma_tau  =M_.params(13); 
nu =M_.params(14); 
gss=M_.params(15); 
rho_z =M_.params(16); 
sigma_z =M_.params(17); 
rho_g =M_.params(18); 
sigma_g  =M_.params(19); 
lambda=M_.params(20); 
omega =M_.params(21); 
delta =M_.params(22); 
kai =M_.params(23); 
ita =M_.params(24); 
tss=M_.params(25); 
a1  =M_.params(26); 
a2 =M_.params(27); 
gamma_g =M_.params(28); 
kbs=M_.params(34); 


rho_s=0.95;
sigma_s=0.33;
D=0.0978;
kappa=70;
sss=-5.2;
%
s=exp(sss);
g=gss;
deltaz=1;
PD=(1-D)*s/(1+s)+1-s/(1+s);
R=1/beta;
R=Rss;
QB=1;


%%
x0=[40;1];
[xx,fval]=fsolve(@dss,x0,optimoptions('fsolve','TolFun',1e-15, 'MaxIter', 1e6),alpha,gss,nu,psi,delta,R,kbs,kai,a1,a2,xi,Pi,ita,PD,tss,gamma_tau,omega,lambda);
K=xx(1);
c=xx(2);

I=((delta-a2)/a1)^(1/(1-xi))*K;
y=(I+c)/(1-g);
QK=(a1*(1-xi)*(( y*(1-g)-c )/K  )^(-xi))^(-1);
RK=( (1-delta)*QK+alpha*y/K   )/QK;
RKs=RK-R;
RBs=RKs/kbs;
RB=RBs+R;
QB=(Pi+(1-Pi)*ita)/( (RKs/kbs+R)/PD-1+Pi   );
B=(y*g-tss)/(  QB-(Pi+(1-Pi)*(ita+QB))+gamma_tau);
N=(psi* ( RK*K+ ( Pi+(1-Pi)*(ita+QB  ) )*B  )-psi*(R* QK*K+R*QB*B  )+omega*( QK*K+QB*B  )      )/(1-psi*R);
alphaS=lambda*(kbs*QK*K+QB*B)/N;
Omega=(1-psi+psi*alphaS)/R;
mu=1-Omega*R/alphaS;
P=R*(QK*K+QB*B-N);


%% 

for iter = 1:length(M_.params) %update parameters set in the file
  eval([ 'M_.params(' num2str(iter) ') = ' M_.param_names(iter,:) ';' ])
end

NumberOfEndogenousVariables = M_.orig_endo_nbr; %auxiliary variables are set automatically
for ii = 1:NumberOfEndogenousVariables
  varname = deblank(M_.endo_names(ii,:));
  eval(['ys(' int2str(ii) ') = ' varname ';']);
end

function y=dss(xx, alpha,gss,nu,psi,delta,R,kbs,kai,a1,a2,xi,Pi,ita,PD,tss,gamma_tau,omega,lambda)

K=xx(1);
c=xx(2);

I=((delta-a2)/a1)^(1/(1-xi))*K;
g=gss;
y=(I+c)/(1-g);
QK=(a1*(1-xi)*(( y*(1-g)-c )/K  )^(-xi))^(-1);
RK=( (1-delta)*QK+alpha*y/K   )/QK;
RKs=RK-R;
RBs=RKs/kbs;
RB=RBs+R;
QB=(Pi+(1-Pi)*ita)/( (RKs/kbs+R)/PD-1+Pi   );
B=(y*g-tss)/(  QB-(Pi+(1-Pi)*(ita+QB))+gamma_tau);
N=(psi* ( RK*K+ ( Pi+(1-Pi)*(ita+QB  ) )*B  )-psi*(R* QK*K+R*QB*B  )+omega*( QK*K+QB*B  )      )/(1-psi*R);
alphaS=lambda*(kbs*K+B)/N;
Omega=(1-psi+psi*alphaS)/R;
mu=1-Omega*R/alphaS;

% equations
f1=y-(K*1^(1/alpha))^(alpha*(1+nu)/(nu+alpha)   )*( (1-alpha)/(kai*c)  )^( (1-alpha)/(nu+alpha) );
f2=Omega*(RKs)-lambda*kbs*mu;
y=[f1;f2];

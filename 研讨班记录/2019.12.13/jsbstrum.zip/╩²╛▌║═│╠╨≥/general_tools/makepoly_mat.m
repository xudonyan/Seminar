% xmat=makepoly(ord,x);
%
%            For the (Tx2) matrix x and the (1x2) vector ord
%            this creates a [T x ord(1)*ord(2)] matrix where 
%            each row contains the ord(1)*ord(2) bivariate Chebyshev 
%            polynomial terms.
%
%		    November 9 1998
%
% ------------------------------------------------------------------

function xmat0=makepoly_mat(ord,x);

% 
% po_1=3;
% po_2=3;
% po_3=3;
% po_4=3;
% po_5=3;
% po_6=3;
% 

po_1   = ord(1);
po_2    = ord(2);
po_3    = ord(3);
po_4   = ord(4);
po_5    = ord(5);
po_6    = ord(6);
x1      = chebpol_mat(po_1,x(:,:,1));
x2      = chebpol_mat(po_2,x(:,:,2));
x3      = chebpol_mat(po_2,x(:,:,3));
x4     = chebpol_mat(po_2,x(:,:,4));
x5      = chebpol_mat(po_2,x(:,:,5));
x6     = chebpol_mat(po_2,x(:,:,6));
% x1=x;
% x2=x;
% x3=x;
% x4=x;
% x5=x;
% x6=x;
% tic
% x11=zeros(4096,100,400);
% toc
% tic
%  x11=repmat(x1,1,1,100);
%  toc
 
for j1  = 0:po_1;
	for j2  = 0:po_2;
        for j3 = 0:po_3;
            for j4 = 0:po_4;
                for j5 = 0:po_5;
                    for j6 = 0:po_6;
		xmat0(:,:,j1*(po_2+1)*(po_3+1)*(po_4+1)*(po_5+1)*(po_6+1)+j2*(po_3+1)*(po_4+1)*(po_5+1)*(po_6+1)+j3*(po_4+1)*(po_5+1)*(po_6+1)+j4*(po_5+1)*(po_6+1)+j5*(po_6+1) +j6+1   ) = x1(:,:,j1+1).*x2(:,:,j2+1).*x3(:,:,j3+1).*x4(:,:,j4+1).*x5(:,:,j5+1).*x6(:,:,j6+1);
                   end;
               end;
            end;
        end;
    end;
end;

% **********************************************************************

% **********************************************************************

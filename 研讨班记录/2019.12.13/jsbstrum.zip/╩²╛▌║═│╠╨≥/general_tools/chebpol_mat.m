% x=chebpol(ord,p);
% Purpose
% Create an ord-th order Chebyshev Polynomial 
% if p	is a vector then the polynomial will be created based 
%	on that vector
% November 9 1998
%
% ----------------------------------------------------------------------
function x=chebpol_mat(ord,p)
% p=lnK2_d0_e;
% ord=3;
	[r c]	= size(p);
 	x	= ones(r,c,ord+1);	
	x(:,:,2)	= p;
	if ord >= 2;
	    for i	= 3:ord+1;
		x(:,:,i)	= 2.*p.*x(:,:,i-1)-x(:,:,i-2);
        end;
	end;

% **********************************************************************

% **********************************************************************

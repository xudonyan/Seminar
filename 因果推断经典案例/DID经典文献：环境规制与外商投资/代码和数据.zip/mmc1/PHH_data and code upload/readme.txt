This set of files contains the replication files for "Does Environmental Regulation Drive away Inbound Foreign Direct Investment? Evidence from a Quasi-Natural Experiment in China".

The code ��result.do�� creates Table 1, Table 2, Table 3, Table 4, Table 5 and Table A3, Figure 2a, Figure 2b, Figure 3, Figure 4a and Figure 4b.
The data ��summary.dta��includes summary statistics and description of variables before 1998, and it creats Table 1.
The data ��census.dta��is the census data, and it creates Table 2, Table 3 and Table 4.
The data ��estimated_coefficient.dta�� ,including coefficients for TCZ*So2*Year Dummies, creates Figure 3.
The data ��fdi_inflow.dta�� , including the FDI net inflow, creates Figure 2a.
The data   "FDI_by_TCZ", including the FDI in TCZ cities and nonTCZ cities, creats Figure 2b
The data ��FIE.dta�� is the FIE data, and it creates Table 2, Table 3 and Table 5
The data ��placebo.dta��includes the estimated coefficients and p value for 500 randomized assignment exercises using census and FIE, and it creates Table 3, Figure 4a, and Figure 4b.
